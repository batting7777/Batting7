import { pgTable, text, serial, integer, boolean, timestamp, jsonb, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  balance: decimal("balance", { precision: 10, scale: 2 }).notNull().default("1000"),
  isAdmin: boolean("is_admin").notNull().default(false),
  referralCode: text("referral_code").notNull().unique(),
  referredBy: integer("referred_by").references(() => users.id),
  referralBalance: decimal("referral_balance", { precision: 10, scale: 2 }).notNull().default("0"),
  winLimit: decimal("win_limit", { precision: 10, scale: 2 }),
  alwaysWin: boolean("always_win").default(false),
  alwaysLose: boolean("always_lose").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const usersRelations = relations(users, ({ many, one }) => ({
  gameHistories: many(gameHistory),
  transactions: many(transactions),
  withdrawalRequests: many(withdrawalRequests),
  referrer: one(users, {
    fields: [users.referredBy],
    references: [users.id],
  }),
}));

export const gameHistory = pgTable("game_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  gameType: text("game_type").notNull(),
  betAmount: decimal("bet_amount", { precision: 10, scale: 2 }).notNull(),
  outcome: text("outcome").notNull(),
  winAmount: decimal("win_amount", { precision: 10, scale: 2 }).notNull(),
  gameState: jsonb("game_state"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const gameHistoryRelations = relations(gameHistory, ({ one }) => ({
  user: one(users, {
    fields: [gameHistory.userId],
    references: [users.id],
  }),
}));

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // deposit, withdrawal, win, loss, referral
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull(), // pending, completed, failed
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
}));

export const withdrawalRequests = pgTable("withdrawal_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("pending"), // pending, approved, rejected
  utrNumber: text("utr_number"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const withdrawalRequestsRelations = relations(withdrawalRequests, ({ one }) => ({
  user: one(users, {
    fields: [withdrawalRequests.userId],
    references: [users.id],
  }),
}));

export const depositRequests = pgTable("deposit_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  method: text("method").notNull(), // "upi" or "usdt"
  utrNumber: text("utr_number"), // For UPI deposits
  walletAddress: text("wallet_address"), // For USDT deposits
  status: text("status").notNull().default("pending"), // pending, approved, rejected
  rejectionCount: integer("rejection_count").default(0), // Track rejected USDT deposits
  isUsdtBlocked: boolean("is_usdt_blocked").default(false), // Flag to block USDT deposits
  notes: text("notes"),
  screenshotUrl: text("screenshot_url"), // For proof of payment
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const depositRequestsRelations = relations(depositRequests, ({ one }) => ({
  user: one(users, {
    fields: [depositRequests.userId],
    references: [users.id],
  }),
}));

export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  minWithdrawalAmount: decimal("min_withdrawal_amount", { precision: 10, scale: 2 }).notNull().default("100"),
  maxWithdrawalAmount: decimal("max_withdrawal_amount", { precision: 10, scale: 2 }).notNull().default("10000"),
  referralBonus: decimal("referral_bonus", { precision: 10, scale: 2 }).notNull().default("100"),
  welcomeBonus: decimal("welcome_bonus", { precision: 10, scale: 2 }).notNull().default("0"),
  upiId: text("upi_id").default("example@upi"),  // UPI ID for deposits
  upiQrUrl: text("upi_qr_url").default("https://example.com/qr.png"), // QR code URL
  usdtAddress: text("usdt_address").default("0x1234567890abcdef"), // USDT wallet address
  usdtQrUrl: text("usdt_qr_url").default("https://example.com/usdt_qr.png"), // USDT QR code URL
  minUpiDeposit: decimal("min_upi_deposit", { precision: 10, scale: 2 }).notNull().default("500"),
  maxUpiDeposit: decimal("max_upi_deposit", { precision: 10, scale: 2 }).notNull().default("30000"),
  minUsdtDeposit: decimal("min_usdt_deposit", { precision: 10, scale: 2 }).notNull().default("10"),
  maxUsdtRejections: integer("max_usdt_rejections").notNull().default(3),
  // Game win chances (0-100 percentage)
  coinTossWinChance: integer("coin_toss_win_chance").notNull().default(50),
  diceRollWinChance: integer("dice_roll_win_chance").notNull().default(50),
  cardFlipWinChance: integer("card_flip_win_chance").notNull().default(50),
  wheelFortuneWinChance: integer("wheel_fortune_win_chance").notNull().default(50),
  luckyNumberWinChance: integer("lucky_number_win_chance").notNull().default(50),
  // Payment QR codes (multiple)
  additionalUpiIds: jsonb("additional_upi_ids").default('[]'),
  additionalUpiQrUrls: jsonb("additional_upi_qr_urls").default('[]'),
  additionalCryptoAddresses: jsonb("additional_crypto_addresses").default('[]'),
  additionalCryptoQrUrls: jsonb("additional_crypto_qr_urls").default('[]'),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Zod validation schemas
export const insertUserSchema = createInsertSchema(users, {
  username: (schema) => schema.min(3, "Username must be at least 3 characters"),
  password: (schema) => schema.min(6, "Password must be at least 6 characters"),
}).omit({ createdAt: true, isAdmin: true, alwaysWin: true, alwaysLose: true, winLimit: true });

export const loginUserSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const placeVetSchema = z.object({
  gameType: z.string(),
  betAmount: z.string().transform(val => parseFloat(val)),
  choice: z.string(),
});

export const gameOutcomeSchema = z.object({
  userId: z.number(),
  gameType: z.string(),
  betAmount: z.number(),
  outcome: z.string(),
  winAmount: z.number(),
  gameState: z.any().optional(),
});

export const withdrawalRequestSchema = z.object({
  amount: z.string().transform(val => parseFloat(val)),
  utrNumber: z.string().optional(),
});

export const adminUpdateUserSchema = z.object({
  alwaysWin: z.boolean().optional(),
  alwaysLose: z.boolean().optional(),
  winLimit: z.number().nullable().optional(),
  balance: z.number().optional(),
});

export const adminUpdateSettingsSchema = z.object({
  minWithdrawalAmount: z.number(),
  maxWithdrawalAmount: z.number(),
  referralBonus: z.number(),
  welcomeBonus: z.number().optional(),
  upiId: z.string().optional(),
  upiQrUrl: z.string().optional(),
  usdtAddress: z.string().optional(),
  usdtQrUrl: z.string().optional(),
  minUpiDeposit: z.number().optional(),
  maxUpiDeposit: z.number().optional(),
  minUsdtDeposit: z.number().optional(),
  maxUsdtRejections: z.number().optional(),
  coinTossWinChance: z.number().min(0).max(100).optional(),
  diceRollWinChance: z.number().min(0).max(100).optional(),
  cardFlipWinChance: z.number().min(0).max(100).optional(),
  wheelFortuneWinChance: z.number().min(0).max(100).optional(),
  luckyNumberWinChance: z.number().min(0).max(100).optional(),
  additionalUpiIds: z.array(z.string()).optional(),
  additionalUpiQrUrls: z.array(z.string()).optional(),
  additionalCryptoAddresses: z.array(z.string()).optional(),
  additionalCryptoQrUrls: z.array(z.string()).optional(),
});

export const depositRequestSchema = z.object({
  amount: z.string().transform(val => parseFloat(val)),
  method: z.enum(["upi", "usdt"]),
  utrNumber: z.string().optional(),
  walletAddress: z.string().optional(),
  screenshotUrl: z.string().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;
export type User = typeof users.$inferSelect;
export type GameHistory = typeof gameHistory.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type WithdrawalRequest = typeof withdrawalRequests.$inferSelect;
export type DepositRequest = typeof depositRequests.$inferSelect;
export type SystemSettings = typeof systemSettings.$inferSelect;
export type GameOutcome = z.infer<typeof gameOutcomeSchema>;
export type WithdrawalRequestInput = z.infer<typeof withdrawalRequestSchema>;
export type DepositRequestInput = z.infer<typeof depositRequestSchema>;
export type AdminUpdateUser = z.infer<typeof adminUpdateUserSchema>;
export type AdminUpdateSettings = z.infer<typeof adminUpdateSettingsSchema>;
