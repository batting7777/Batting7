import { db } from "./index";
import * as schema from "@shared/schema";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import { and, eq } from "drizzle-orm";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

function generateReferralCode(length = 8) {
  const characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

async function seed() {
  try {
    // Create admin user if it doesn't exist
    const existingAdmin = await db.query.users.findFirst({
      where: eq(schema.users.username, "admin"),
    });

    if (!existingAdmin) {
      await db.insert(schema.users).values({
        username: "admin",
        password: await hashPassword("admin123"),
        isAdmin: true,
        referralCode: generateReferralCode(),
      });
      console.log("Admin user created successfully");
    }

    // Create test user if it doesn't exist
    const existingUser = await db.query.users.findFirst({
      where: eq(schema.users.username, "testuser"),
    });

    if (!existingUser) {
      await db.insert(schema.users).values({
        username: "testuser",
        password: await hashPassword("test123"),
        referralCode: generateReferralCode(),
      });
      console.log("Test user created successfully");
    }

    // Create system settings if they don't exist
    const existingSettings = await db.query.systemSettings.findFirst();

    if (!existingSettings) {
      await db.insert(schema.systemSettings).values({
        minWithdrawalAmount: "100",
        maxWithdrawalAmount: "10000",
        referralBonus: "100",
      });
      console.log("System settings created successfully");
    }

    console.log("Seed completed successfully");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
