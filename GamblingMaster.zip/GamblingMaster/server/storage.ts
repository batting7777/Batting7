import { db } from "@db";
import { pool } from "@db";
import session from "express-session";
import connectPg from "connect-pg-simple";
import * as schema from "@shared/schema";
import { and, eq, desc, gt, lt, gte, lte, SQL } from "drizzle-orm";
import { 
  GameOutcome, 
  Transaction, 
  WithdrawalRequest, 
  DepositRequest, 
  DepositRequestInput 
} from "@shared/schema";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<schema.User | undefined>;
  getUserByUsername(username: string): Promise<schema.User | undefined>;
  getUserByReferralCode(code: string): Promise<schema.User | undefined>;
  createUser(user: Partial<schema.User>): Promise<schema.User>;
  updateUser(id: number, data: Partial<schema.User>): Promise<schema.User | undefined>;
  getAllUsers(): Promise<schema.User[]>;
  updateUserBalance(id: number, amount: number): Promise<schema.User | undefined>;
  updateUserReferralBalance(id: number, amount: number): Promise<schema.User | undefined>;
  
  // Game history methods
  createGameHistory(gameOutcome: GameOutcome): Promise<schema.GameHistory>;
  getUserGameHistory(userId: number): Promise<schema.GameHistory[]>;
  getAllGameHistory(): Promise<schema.GameHistory[]>;
  
  // Transaction methods
  createTransaction(transaction: Partial<Transaction>): Promise<schema.Transaction>;
  getUserTransactions(userId: number): Promise<schema.Transaction[]>;
  getAllTransactions(): Promise<schema.Transaction[]>;
  
  // Withdrawal methods
  createWithdrawalRequest(withdrawal: Partial<WithdrawalRequest>): Promise<schema.WithdrawalRequest>;
  getUserWithdrawals(userId: number): Promise<schema.WithdrawalRequest[]>;
  getAllWithdrawals(): Promise<schema.WithdrawalRequest[]>;
  updateWithdrawalStatus(id: number, status: string, utrNumber?: string): Promise<schema.WithdrawalRequest | undefined>;
  
  // Deposit methods
  createDepositRequest(deposit: Partial<DepositRequest>): Promise<schema.DepositRequest>;
  getUserDepositRequests(userId: number): Promise<schema.DepositRequest[]>;
  getAllDepositRequests(): Promise<schema.DepositRequest[]>;
  updateDepositStatus(id: number, status: string, notes?: string): Promise<schema.DepositRequest | undefined>;
  checkUserUsdtBlocked(userId: number): Promise<boolean>;
  updateUsdtBlockStatus(userId: number, isBlocked: boolean): Promise<schema.DepositRequest | undefined>;
  
  // System settings
  getSystemSettings(): Promise<schema.SystemSettings | undefined>;
  updateSystemSettings(settings: Partial<schema.SystemSettings>): Promise<schema.SystemSettings | undefined>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool,
      createTableIfMissing: true 
    });
  }
  
  async getUser(id: number): Promise<schema.User | undefined> {
    return await db.query.users.findFirst({
      where: eq(schema.users.id, id)
    });
  }
  
  async getUserByUsername(username: string): Promise<schema.User | undefined> {
    return await db.query.users.findFirst({
      where: eq(schema.users.username, username)
    });
  }
  
  async getUserByReferralCode(code: string): Promise<schema.User | undefined> {
    return await db.query.users.findFirst({
      where: eq(schema.users.referralCode, code)
    });
  }
  
  async createUser(user: Partial<schema.User>): Promise<schema.User> {
    const [newUser] = await db.insert(schema.users).values(user).returning();
    return newUser;
  }
  
  async updateUser(id: number, data: Partial<schema.User>): Promise<schema.User | undefined> {
    const [updatedUser] = await db.update(schema.users)
      .set(data)
      .where(eq(schema.users.id, id))
      .returning();
    return updatedUser;
  }
  
  async getAllUsers(): Promise<schema.User[]> {
    return await db.query.users.findMany({
      orderBy: desc(schema.users.createdAt)
    });
  }
  
  async updateUserBalance(id: number, amount: number): Promise<schema.User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const newBalance = parseFloat(user.balance.toString()) + amount;
    
    const [updatedUser] = await db.update(schema.users)
      .set({ balance: newBalance.toString() })
      .where(eq(schema.users.id, id))
      .returning();
    
    return updatedUser;
  }
  
  async updateUserReferralBalance(id: number, amount: number): Promise<schema.User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const newReferralBalance = parseFloat(user.referralBalance.toString()) + amount;
    
    const [updatedUser] = await db.update(schema.users)
      .set({ referralBalance: newReferralBalance.toString() })
      .where(eq(schema.users.id, id))
      .returning();
    
    return updatedUser;
  }
  
  async createGameHistory(gameOutcome: GameOutcome): Promise<schema.GameHistory> {
    const [newHistory] = await db.insert(schema.gameHistory).values({
      userId: gameOutcome.userId,
      gameType: gameOutcome.gameType,
      betAmount: gameOutcome.betAmount.toString(),
      outcome: gameOutcome.outcome,
      winAmount: gameOutcome.winAmount.toString(),
      gameState: gameOutcome.gameState
    }).returning();
    
    return newHistory;
  }
  
  async getUserGameHistory(userId: number): Promise<schema.GameHistory[]> {
    return await db.query.gameHistory.findMany({
      where: eq(schema.gameHistory.userId, userId),
      orderBy: desc(schema.gameHistory.createdAt),
      with: {
        user: true
      }
    });
  }
  
  async getAllGameHistory(): Promise<schema.GameHistory[]> {
    return await db.query.gameHistory.findMany({
      orderBy: desc(schema.gameHistory.createdAt),
      with: {
        user: true
      }
    });
  }
  
  async createTransaction(transaction: Partial<Transaction>): Promise<schema.Transaction> {
    const [newTransaction] = await db.insert(schema.transactions).values(transaction).returning();
    return newTransaction;
  }
  
  async getUserTransactions(userId: number): Promise<schema.Transaction[]> {
    return await db.query.transactions.findMany({
      where: eq(schema.transactions.userId, userId),
      orderBy: desc(schema.transactions.createdAt)
    });
  }
  
  async getAllTransactions(): Promise<schema.Transaction[]> {
    return await db.query.transactions.findMany({
      orderBy: desc(schema.transactions.createdAt),
      with: {
        user: true
      }
    });
  }
  
  async createWithdrawalRequest(withdrawal: Partial<WithdrawalRequest>): Promise<schema.WithdrawalRequest> {
    const [newWithdrawal] = await db.insert(schema.withdrawalRequests).values(withdrawal).returning();
    return newWithdrawal;
  }
  
  async getUserWithdrawals(userId: number): Promise<schema.WithdrawalRequest[]> {
    return await db.query.withdrawalRequests.findMany({
      where: eq(schema.withdrawalRequests.userId, userId),
      orderBy: desc(schema.withdrawalRequests.createdAt)
    });
  }
  
  async getAllWithdrawals(): Promise<schema.WithdrawalRequest[]> {
    return await db.query.withdrawalRequests.findMany({
      orderBy: desc(schema.withdrawalRequests.createdAt),
      with: {
        user: true
      }
    });
  }
  
  async updateWithdrawalStatus(id: number, status: string, utrNumber?: string): Promise<schema.WithdrawalRequest | undefined> {
    const updateData: Partial<WithdrawalRequest> = { 
      status, 
      updatedAt: new Date() 
    };
    
    if (utrNumber) {
      updateData.utrNumber = utrNumber;
    }
    
    const [updatedWithdrawal] = await db.update(schema.withdrawalRequests)
      .set(updateData)
      .where(eq(schema.withdrawalRequests.id, id))
      .returning();
    
    return updatedWithdrawal;
  }
  
  async getSystemSettings(): Promise<schema.SystemSettings | undefined> {
    return await db.query.systemSettings.findFirst();
  }
  
  async createDepositRequest(deposit: Partial<DepositRequest>): Promise<schema.DepositRequest> {
    // Add updatedAt timestamp
    const depositData = {
      ...deposit,
      updatedAt: new Date()
    };
    
    const [newDeposit] = await db.insert(schema.depositRequests).values(depositData).returning();
    return newDeposit;
  }
  
  async getUserDepositRequests(userId: number): Promise<schema.DepositRequest[]> {
    return await db.query.depositRequests.findMany({
      where: eq(schema.depositRequests.userId, userId),
      orderBy: desc(schema.depositRequests.createdAt)
    });
  }
  
  async getAllDepositRequests(): Promise<schema.DepositRequest[]> {
    return await db.query.depositRequests.findMany({
      orderBy: desc(schema.depositRequests.createdAt),
      with: {
        user: true
      }
    });
  }
  
  async updateDepositStatus(id: number, status: string, notes?: string): Promise<schema.DepositRequest | undefined> {
    const deposit = await db.query.depositRequests.findFirst({
      where: eq(schema.depositRequests.id, id)
    });
    
    if (!deposit) return undefined;
    
    const updateData: Partial<DepositRequest> = { 
      status, 
      updatedAt: new Date() 
    };
    
    if (notes) {
      updateData.notes = notes;
    }
    
    // If rejecting a USDT deposit, increment rejection count
    if (status === "rejected" && deposit.method === "usdt") {
      updateData.rejectionCount = (deposit.rejectionCount || 0) + 1;
      
      // Check if user has reached max rejections
      const settings = await this.getSystemSettings();
      if (settings && (deposit.rejectionCount || 0) + 1 >= settings.maxUsdtRejections) {
        updateData.isUsdtBlocked = true;
      }
    }
    
    const [updatedDeposit] = await db.update(schema.depositRequests)
      .set(updateData)
      .where(eq(schema.depositRequests.id, id))
      .returning();
    
    return updatedDeposit;
  }
  
  async checkUserUsdtBlocked(userId: number): Promise<boolean> {
    // Check if user has any deposit request with isUsdtBlocked = true
    const blockedRequest = await db.query.depositRequests.findFirst({
      where: and(
        eq(schema.depositRequests.userId, userId),
        eq(schema.depositRequests.isUsdtBlocked, true)
      )
    });
    
    return !!blockedRequest;
  }
  
  async updateUsdtBlockStatus(userId: number, isBlocked: boolean): Promise<schema.DepositRequest | undefined> {
    // Find the most recent USDT deposit request for this user
    const latestDeposit = await db.query.depositRequests.findFirst({
      where: and(
        eq(schema.depositRequests.userId, userId),
        eq(schema.depositRequests.method, "usdt")
      ),
      orderBy: desc(schema.depositRequests.createdAt)
    });
    
    if (!latestDeposit) return undefined;
    
    // Update the block status
    const [updatedDeposit] = await db.update(schema.depositRequests)
      .set({ 
        isUsdtBlocked: isBlocked,
        updatedAt: new Date()
      })
      .where(eq(schema.depositRequests.id, latestDeposit.id))
      .returning();
    
    return updatedDeposit;
  }
  
  async updateSystemSettings(settings: Partial<schema.SystemSettings>): Promise<schema.SystemSettings | undefined> {
    const systemSettings = await this.getSystemSettings();
    
    if (!systemSettings) {
      const [newSettings] = await db.insert(schema.systemSettings)
        .values({
          ...settings,
          updatedAt: new Date()
        })
        .returning();
      return newSettings;
    }
    
    const [updatedSettings] = await db.update(schema.systemSettings)
      .set({
        ...settings,
        updatedAt: new Date()
      })
      .where(eq(schema.systemSettings.id, systemSettings.id))
      .returning();
    
    return updatedSettings;
  }
}

// Export singleton instance
export const storage = new DatabaseStorage();
