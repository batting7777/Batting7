import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { db } from "@db";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import * as schema from "@shared/schema";
import { and, eq, desc } from "drizzle-orm";
import { 
  gameOutcomeSchema, 
  withdrawalRequestSchema, 
  adminUpdateUserSchema, 
  adminUpdateSettingsSchema,
  depositRequestSchema
} from "@shared/schema";

function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

function isAdmin(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && req.user.isAdmin) {
    return next();
  }
  res.status(403).json({ message: "Access denied" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup auth routes
  setupAuth(app);

  // Games routes
  app.post("/api/games/bet", isAuthenticated, async (req, res, next) => {
    try {
      const { gameType, betAmount, choice } = req.body;
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Validate bet amount
      const betAmountNum = parseFloat(betAmount);
      if (isNaN(betAmountNum) || betAmountNum <= 0) {
        return res.status(400).json({ message: "Invalid bet amount" });
      }
      
      const userBalance = parseFloat(user.balance.toString());
      if (userBalance < betAmountNum) {
        return res.status(400).json({ message: "Insufficient balance" });
      }
      
      // Prepare variables for game outcome
      let outcome = "loss";
      let winAmount = 0;
      let gameState = {};
      
      // Check for admin-set conditions
      let shouldWin = user.alwaysWin;
      let shouldLose = user.alwaysLose;
      
      // Check win limit if set
      if (user.winLimit !== null) {
        const totalWins = await calculateUserWinnings(userId);
        if (totalWins >= parseFloat(user.winLimit?.toString() || "0")) {
          shouldLose = true;
          shouldWin = false;
        }
      }
      
      // Calculate game outcome based on game type
      switch (gameType) {
        case "coinToss": {
          const coinResult = shouldWin ? choice : (shouldLose ? (choice === "heads" ? "tails" : "heads") : (Math.random() < 0.5 ? "heads" : "tails"));
          outcome = coinResult === choice ? "win" : "loss";
          winAmount = outcome === "win" ? betAmountNum * 2 : 0;
          gameState = { result: coinResult, choice };
          break;
        }
        case "diceRoll": {
          const choiceNum = parseInt(choice);
          const diceResult = shouldWin ? choiceNum : (shouldLose ? ((choiceNum % 6) + 1) : Math.floor(Math.random() * 6) + 1);
          outcome = diceResult === choiceNum ? "win" : "loss";
          winAmount = outcome === "win" ? betAmountNum * 6 : 0;
          gameState = { result: diceResult, choice: choiceNum };
          break;
        }
        case "wheelFortune": {
          const multipliers = [0, 0.5, 1.5, 0, 2, 0, 3, 0];
          const wheelIndex = shouldWin ? multipliers.findIndex(m => m >= 1.5) : 
                            (shouldLose ? multipliers.findIndex(m => m === 0) : 
                            Math.floor(Math.random() * multipliers.length));
          const multiplier = multipliers[wheelIndex];
          outcome = multiplier > 0 ? "win" : "loss";
          winAmount = betAmountNum * multiplier;
          gameState = { result: wheelIndex, multiplier };
          break;
        }
        case "cardFlip": {
          const cards = ["A", "K", "Q", "J"];
          const selectedCard = choice;
          const resultCard = shouldWin ? selectedCard : (shouldLose ? cards.find(c => c !== selectedCard) : cards[Math.floor(Math.random() * cards.length)]);
          outcome = resultCard === selectedCard ? "win" : "loss";
          winAmount = outcome === "win" ? betAmountNum * 4 : 0;
          gameState = { result: resultCard, choice: selectedCard };
          break;
        }
        case "luckyNumber": {
          const choiceNum = parseInt(choice);
          const resultNum = shouldWin ? choiceNum : (shouldLose ? ((choiceNum % 10) + 1) : Math.floor(Math.random() * 10) + 1);
          outcome = resultNum === choiceNum ? "win" : "loss";
          winAmount = outcome === "win" ? betAmountNum * 10 : 0;
          gameState = { result: resultNum, choice: choiceNum };
          break;
        }
        default:
          return res.status(400).json({ message: "Invalid game type" });
      }
      
      // Create game history record
      const gameOutcome = {
        userId,
        gameType,
        betAmount: betAmountNum,
        outcome,
        winAmount,
        gameState
      };
      
      const gameHistory = await storage.createGameHistory(gameOutcome);
      
      // Update user balance
      const balanceChange = winAmount - betAmountNum;
      await storage.updateUserBalance(userId, balanceChange);
      
      // Create transaction record
      await storage.createTransaction({
        userId,
        type: outcome === "win" ? "win" : "loss",
        amount: outcome === "win" ? winAmount : betAmountNum,
        status: "completed",
        notes: `${gameType} game - ${outcome}`
      });
      
      // Get updated user info
      const updatedUser = await storage.getUser(userId);
      
      res.json({
        game: gameHistory,
        outcome,
        winAmount,
        gameState,
        newBalance: updatedUser?.balance
      });
    } catch (error) {
      next(error);
    }
  });
  
  // Get user game history
  app.get("/api/games/history", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const history = await storage.getUserGameHistory(userId);
      res.json(history);
    } catch (error) {
      next(error);
    }
  });
  
  // Wallet/Transaction routes
  app.get("/api/wallet/transactions", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const transactions = await storage.getUserTransactions(userId);
      res.json(transactions);
    } catch (error) {
      next(error);
    }
  });
  
  // Withdrawal routes
  app.post("/api/wallet/withdraw", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const { amount } = withdrawalRequestSchema.parse(req.body);
      
      // Get user and system settings
      const user = await storage.getUser(userId);
      const settings = await storage.getSystemSettings();
      
      if (!user || !settings) {
        return res.status(404).json({ message: "User or settings not found" });
      }
      
      const userBalance = parseFloat(user.balance.toString());
      const minAmount = parseFloat(settings.minWithdrawalAmount.toString());
      const maxAmount = parseFloat(settings.maxWithdrawalAmount.toString());
      
      // Validate withdrawal amount
      if (amount < minAmount) {
        return res.status(400).json({ message: `Minimum withdrawal amount is ₹${minAmount}` });
      }
      
      if (amount > maxAmount) {
        return res.status(400).json({ message: `Maximum withdrawal amount is ₹${maxAmount}` });
      }
      
      if (amount > userBalance) {
        return res.status(400).json({ message: "Insufficient balance" });
      }
      
      // Create withdrawal request
      const withdrawal = await storage.createWithdrawalRequest({
        userId,
        amount: amount.toString(),
        status: "pending"
      });
      
      // Deduct from user balance
      await storage.updateUserBalance(userId, -amount);
      
      // Create transaction record
      await storage.createTransaction({
        userId,
        type: "withdrawal",
        amount: amount.toString(),
        status: "pending",
        notes: "Withdrawal request"
      });
      
      res.status(201).json(withdrawal);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/wallet/withdrawals", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const withdrawals = await storage.getUserWithdrawals(userId);
      res.json(withdrawals);
    } catch (error) {
      next(error);
    }
  });
  
  // Referral routes
  app.get("/api/settings", isAuthenticated, async (req, res, next) => {
    try {
      const settings = await storage.getSystemSettings();
      if (!settings) {
        return res.status(404).json({ message: "Settings not found" });
      }
      res.json(settings);
    } catch (error) {
      next(error);
    }
  });
  
  // Admin routes
  app.get("/api/admin/users", isAdmin, async (req, res, next) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/admin/games/history", isAdmin, async (req, res, next) => {
    try {
      const history = await storage.getAllGameHistory();
      res.json(history);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/admin/transactions", isAdmin, async (req, res, next) => {
    try {
      const transactions = await storage.getAllTransactions();
      res.json(transactions);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/admin/withdrawals", isAdmin, async (req, res, next) => {
    try {
      const withdrawals = await storage.getAllWithdrawals();
      res.json(withdrawals);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/admin/users/:id", isAdmin, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.id);
      const updateData = adminUpdateUserSchema.parse(req.body);
      
      const updatedUser = await storage.updateUser(userId, updateData);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/admin/withdrawals/:id", isAdmin, async (req, res, next) => {
    try {
      const withdrawalId = parseInt(req.params.id);
      const { status, utrNumber } = req.body;
      
      if (!["approved", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const withdrawal = await storage.updateWithdrawalStatus(withdrawalId, status, utrNumber);
      if (!withdrawal) {
        return res.status(404).json({ message: "Withdrawal request not found" });
      }
      
      // If approved, update transaction status
      if (status === "approved" || status === "rejected") {
        const transactions = await storage.getUserTransactions(withdrawal.userId);
        const transaction = transactions.find(t => 
          t.type === "withdrawal" && 
          t.amount === withdrawal.amount.toString() && 
          t.status === "pending"
        );
        
        if (transaction) {
          await storage.createTransaction({
            userId: withdrawal.userId,
            type: "withdrawal",
            amount: withdrawal.amount.toString(),
            status: status === "approved" ? "completed" : "failed",
            notes: status === "approved" ? `Withdrawal approved. UTR: ${utrNumber}` : `Withdrawal rejected`
          });
        }
        
        // If rejected, add funds back to user balance
        if (status === "rejected") {
          const amount = parseFloat(withdrawal.amount.toString());
          await storage.updateUserBalance(withdrawal.userId, amount);
        }
      }
      
      res.json(withdrawal);
    } catch (error) {
      next(error);
    }
  });
  
  app.put("/api/admin/settings", isAdmin, async (req, res, next) => {
    try {
      const settings = adminUpdateSettingsSchema.parse(req.body);
      
      // Prepare the update data
      const updateData: Record<string, any> = {
        minWithdrawalAmount: settings.minWithdrawalAmount.toString(),
        maxWithdrawalAmount: settings.maxWithdrawalAmount.toString(),
        referralBonus: settings.referralBonus.toString()
      };
      
      // Add welcome bonus if present
      if (settings.welcomeBonus !== undefined) {
        updateData.welcomeBonus = settings.welcomeBonus.toString();
      }
      
      // Add optional deposit settings
      if (settings.upiId) updateData.upiId = settings.upiId;
      if (settings.upiQrUrl) updateData.upiQrUrl = settings.upiQrUrl;
      if (settings.usdtAddress) updateData.usdtAddress = settings.usdtAddress;
      if (settings.usdtQrUrl) updateData.usdtQrUrl = settings.usdtQrUrl;
      if (settings.minUpiDeposit) updateData.minUpiDeposit = settings.minUpiDeposit.toString();
      if (settings.maxUpiDeposit) updateData.maxUpiDeposit = settings.maxUpiDeposit.toString();
      if (settings.minUsdtDeposit) updateData.minUsdtDeposit = settings.minUsdtDeposit.toString();
      if (settings.maxUsdtRejections) updateData.maxUsdtRejections = settings.maxUsdtRejections.toString();
      
      // Add game win chances
      if (settings.coinTossWinChance !== undefined) updateData.coinTossWinChance = settings.coinTossWinChance;
      if (settings.diceRollWinChance !== undefined) updateData.diceRollWinChance = settings.diceRollWinChance;
      if (settings.cardFlipWinChance !== undefined) updateData.cardFlipWinChance = settings.cardFlipWinChance;
      if (settings.wheelFortuneWinChance !== undefined) updateData.wheelFortuneWinChance = settings.wheelFortuneWinChance;
      if (settings.luckyNumberWinChance !== undefined) updateData.luckyNumberWinChance = settings.luckyNumberWinChance;
      
      // Add multiple payment options
      if (settings.additionalUpiIds) updateData.additionalUpiIds = settings.additionalUpiIds;
      if (settings.additionalUpiQrUrls) updateData.additionalUpiQrUrls = settings.additionalUpiQrUrls;
      if (settings.additionalCryptoAddresses) updateData.additionalCryptoAddresses = settings.additionalCryptoAddresses;
      if (settings.additionalCryptoQrUrls) updateData.additionalCryptoQrUrls = settings.additionalCryptoQrUrls;
      
      const updatedSettings = await storage.updateSystemSettings(updateData);
      
      res.json(updatedSettings);
    } catch (error) {
      next(error);
    }
  });
  
  // Deposit routes
  app.get("/api/wallet/deposit-methods", isAuthenticated, async (req, res, next) => {
    try {
      // Get system settings to return deposit method details
      const settings = await storage.getSystemSettings();
      if (!settings) {
        return res.status(500).json({ message: "System settings not found" });
      }
      
      // Check if USDT is blocked for this user
      const isUsdtBlocked = await storage.checkUserUsdtBlocked(req.user.id);
      
      // Return deposit methods info
      res.json({
        upi: {
          id: settings.upiId,
          qrUrl: settings.upiQrUrl,
          minAmount: parseFloat(settings.minUpiDeposit?.toString() || "500"),
          maxAmount: parseFloat(settings.maxUpiDeposit?.toString() || "30000"),
        },
        usdt: {
          address: settings.usdtAddress,
          qrUrl: settings.usdtQrUrl,
          minAmount: parseFloat(settings.minUsdtDeposit?.toString() || "10"),
          isBlocked: isUsdtBlocked,
        }
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/wallet/deposit-request", isAuthenticated, async (req, res, next) => {
    try {
      const validatedData = depositRequestSchema.parse(req.body);
      const { method, amount: amountStr, utrNumber, walletAddress, screenshotUrl } = validatedData;
      
      const amountNum = parseFloat(amountStr);
      
      // Get system settings for validation
      const settings = await storage.getSystemSettings();
      if (!settings) {
        return res.status(500).json({ message: "System settings not found" });
      }
      
      if (method === "upi") {
        // Validate UPI deposit
        const minAmount = parseFloat(settings.minUpiDeposit?.toString() || "500");
        const maxAmount = parseFloat(settings.maxUpiDeposit?.toString() || "30000");
        
        if (amountNum < minAmount) {
          return res.status(400).json({ message: `Minimum UPI deposit amount is ₹${minAmount}` });
        }
        
        if (amountNum > maxAmount) {
          return res.status(400).json({ message: `Maximum UPI deposit amount is ₹${maxAmount}` });
        }
        
        if (!utrNumber || utrNumber.length < 12) {
          return res.status(400).json({ message: "Valid UTR number is required for UPI deposits" });
        }
      } else if (method === "usdt") {
        // Check if USDT deposits are blocked for this user
        const isUsdtBlocked = await storage.checkUserUsdtBlocked(req.user.id);
        if (isUsdtBlocked) {
          return res.status(403).json({ message: "USDT deposits are temporarily blocked for your account" });
        }
        
        // Validate USDT deposit
        const minAmount = parseFloat(settings.minUsdtDeposit?.toString() || "10");
        
        if (amountNum < minAmount) {
          return res.status(400).json({ message: `Minimum USDT deposit amount is ${minAmount}` });
        }
      } else {
        return res.status(400).json({ message: "Invalid deposit method" });
      }
      
      // Create deposit request
      const depositRequest = await storage.createDepositRequest({
        userId: req.user.id,
        amount: amountNum.toString(),
        method,
        utrNumber: method === "upi" ? utrNumber : undefined,
        walletAddress: method === "usdt" ? walletAddress : undefined,
        status: "pending",
        screenshotUrl,
      });
      
      res.status(201).json(depositRequest);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/wallet/deposit-requests", isAuthenticated, async (req, res, next) => {
    try {
      const depositRequests = await storage.getUserDepositRequests(req.user.id);
      res.json(depositRequests);
    } catch (error) {
      next(error);
    }
  });
  
  // Admin endpoint to manage deposit requests
  app.get("/api/admin/deposit-requests", isAdmin, async (req, res, next) => {
    try {
      const depositRequests = await storage.getAllDepositRequests();
      res.json(depositRequests);
    } catch (error) {
      next(error);
    }
  });
  
  // Admin endpoint to approve/reject deposit requests
  app.put("/api/admin/deposit-requests/:id", isAdmin, async (req, res, next) => {
    try {
      const { status, notes } = req.body;
      const depositId = parseInt(req.params.id);
      
      if (!["approved", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status. Must be 'approved' or 'rejected'" });
      }
      
      // Get deposit request
      const depositRequest = await db.query.depositRequests.findFirst({
        where: eq(schema.depositRequests.id, depositId)
      });
      
      if (!depositRequest) {
        return res.status(404).json({ message: "Deposit request not found" });
      }
      
      // Update deposit status
      const updatedRequest = await storage.updateDepositStatus(depositId, status, notes);
      
      if (status === "approved") {
        // Credit user's account
        const amount = parseFloat(depositRequest.amount.toString());
        await storage.updateUserBalance(depositRequest.userId, amount);
        
        // Create transaction record
        await storage.createTransaction({
          userId: depositRequest.userId,
          type: "deposit",
          amount: depositRequest.amount.toString(),
          status: "completed",
          notes: `${depositRequest.method.toUpperCase()} deposit approved`,
        });
      }
      
      res.json(updatedRequest);
    } catch (error) {
      next(error);
    }
  });
  
  // Manual admin endpoint to toggle USDT block status
  app.put("/api/admin/users/:id/usdt-block", isAdmin, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.id);
      const { isBlocked } = req.body;
      
      if (typeof isBlocked !== "boolean") {
        return res.status(400).json({ message: "isBlocked parameter must be a boolean" });
      }
      
      const result = await storage.updateUsdtBlockStatus(userId, isBlocked);
      
      if (!result) {
        return res.status(404).json({ message: "No USDT deposit requests found for this user" });
      }
      
      res.json({ success: true, message: `USDT deposits ${isBlocked ? 'blocked' : 'unblocked'} for user` });
    } catch (error) {
      next(error);
    }
  });

  // Get payment settings (UPI and USDT options)
  app.get('/api/payment-settings', async (req, res, next) => {
    try {
      const settings = await storage.getSystemSettings();
      
      if (!settings) {
        return res.status(404).json({ message: "System settings not found" });
      }
      
      // Parse the UPI options from the JSON string
      let upiOptions = [];
      try {
        upiOptions = settings.upiOptions ? JSON.parse(settings.upiOptions) : [];
      } catch (error) {
        console.error("Error parsing UPI options:", error);
        upiOptions = [];
      }
      
      // Parse the USDT address
      let usdtAddress = '';
      try {
        usdtAddress = settings.usdtAddress || '';
      } catch (error) {
        console.error("Error parsing USDT address:", error);
        usdtAddress = '';
      }
      
      res.json({
        upiOptions,
        usdtAddress
      });
    } catch (error) {
      next(error);
    }
  });
  
  // UPI Deposit endpoint
  app.post('/api/deposit/upi', isAuthenticated, async (req, res, next) => {
    try {
      const { amount, utrNumber } = req.body;
      
      // Validate input
      if (!amount || isNaN(Number(amount)) || Number(amount) < 500 || Number(amount) > 30000) {
        return res.status(400).json({ message: "Invalid amount. Must be between ₹500 and ₹30,000" });
      }
      
      if (!utrNumber || utrNumber.length < 12 || utrNumber.length > 22) {
        return res.status(400).json({ message: "Invalid UTR number" });
      }
      
      // Check if UTR already exists to prevent duplicate deposits
      const allDeposits = await storage.getAllDepositRequests();
      const existingDeposit = allDeposits.find(d => 
        d.utrNumber && d.utrNumber.toLowerCase() === utrNumber.toLowerCase()
      );
      
      if (existingDeposit) {
        return res.status(400).json({ message: "This UTR number has already been used" });
      }
      
      // Create a deposit request
      const deposit = await storage.createDepositRequest({
        userId: req.user!.id,
        amount: amount.toString(),
        method: 'upi',
        status: 'pending',
        utrNumber,
        transactionId: null,
        screenshotUrl: null
      });
      
      // Create a transaction record
      await storage.createTransaction({
        userId: req.user!.id,
        type: 'deposit',
        amount: amount.toString(),
        status: 'pending',
        notes: `UPI deposit with UTR: ${utrNumber}`
      });
      
      res.status(201).json(deposit);
    } catch (error) {
      next(error);
    }
  });
  
  // USDT Deposit endpoint
  app.post('/api/deposit/usdt', isAuthenticated, async (req, res, next) => {
    try {
      const { amount, transactionId } = req.body;
      
      // Validate input
      if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
        return res.status(400).json({ message: "Invalid amount" });
      }
      
      if (!transactionId || transactionId.length < 5) {
        return res.status(400).json({ message: "Invalid transaction ID" });
      }
      
      // Check if the user is blocked from USDT deposits
      const isBlocked = await storage.checkUserUsdtBlocked(req.user!.id);
      if (isBlocked) {
        return res.status(403).json({ 
          message: "Your USDT deposit access has been restricted. Please contact support or use UPI for deposits." 
        });
      }
      
      // Check if transaction ID already exists
      const allDeposits = await storage.getAllDepositRequests();
      const existingDeposit = allDeposits.find(d => 
        d.transactionId && d.transactionId.toLowerCase() === transactionId.toLowerCase()
      );
      
      if (existingDeposit) {
        return res.status(400).json({ message: "This transaction ID has already been used" });
      }
      
      // Create a deposit request
      const deposit = await storage.createDepositRequest({
        userId: req.user!.id,
        amount: amount.toString(),
        method: 'usdt',
        status: 'pending',
        utrNumber: null,
        transactionId,
        screenshotUrl: null
      });
      
      // Create a transaction record
      await storage.createTransaction({
        userId: req.user!.id,
        type: 'deposit',
        amount: amount.toString(),
        status: 'pending',
        notes: `USDT deposit with Transaction ID: ${transactionId}`
      });
      
      res.status(201).json(deposit);
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to calculate total user winnings
async function calculateUserWinnings(userId: number): Promise<number> {
  const history = await storage.getUserGameHistory(userId);
  return history.reduce((total, game) => {
    return total + (game.outcome === "win" ? parseFloat(game.winAmount.toString()) : 0);
  }, 0);
}
