import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  LayoutDashboard, 
  Gamepad2, 
  Wallet, 
  History, 
  Share2, 
  HelpCircle, 
  LogOut,
  Users,
  Settings,
  ShieldAlert
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";

export default function Sidebar({ 
  isMobileOpen, 
  toggleSidebar 
}: { 
  isMobileOpen: boolean,
  toggleSidebar: () => void
}) {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();
  const { toast } = useToast();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const closeMenu = () => {
    if (isMobileOpen) {
      toggleSidebar();
    }
  };
  
  const navItems = [
    {
      title: 'Dashboard',
      icon: <LayoutDashboard className="mr-3 h-5 w-5" />,
      href: '/',
      id: 'dashboard',
      admin: false
    },
    {
      title: 'Games',
      icon: <Gamepad2 className="mr-3 h-5 w-5" />,
      href: '/games',
      id: 'games',
      admin: false
    },
    {
      title: 'Wallet',
      icon: <Wallet className="mr-3 h-5 w-5" />,
      href: '/wallet',
      id: 'wallet',
      admin: false
    },
    {
      title: 'History',
      icon: <History className="mr-3 h-5 w-5" />,
      href: '/history',
      id: 'history',
      admin: false
    },
    {
      title: 'Refer & Earn',
      icon: <Share2 className="mr-3 h-5 w-5" />,
      href: '/referral',
      id: 'referral',
      admin: false
    },
    {
      title: 'Support',
      icon: <HelpCircle className="mr-3 h-5 w-5" />,
      href: '/support',
      id: 'support',
      admin: false
    }
  ];
  
  const adminItems = [
    {
      title: 'Admin Dashboard',
      icon: <ShieldAlert className="mr-3 h-5 w-5" />,
      href: '/admin',
      id: 'admin-dashboard',
      admin: true
    },
    {
      title: 'User Management',
      icon: <Users className="mr-3 h-5 w-5" />,
      href: '/admin/users',
      id: 'admin-users',
      admin: true
    },
    {
      title: 'Game Controls',
      icon: <Gamepad2 className="mr-3 h-5 w-5" />,
      href: '/admin/games',
      id: 'admin-games',
      admin: true
    },
    {
      title: 'Withdrawals',
      icon: <Wallet className="mr-3 h-5 w-5" />,
      href: '/admin/withdrawals',
      id: 'admin-withdrawals',
      admin: true
    },
    {
      title: 'Referral Settings',
      icon: <Share2 className="mr-3 h-5 w-5" />,
      href: '/admin/referrals',
      id: 'admin-referrals',
      admin: true
    },
    {
      title: 'Payment Settings',
      icon: <Settings className="mr-3 h-5 w-5" />,
      href: '/admin/payment-settings',
      id: 'admin-payment-settings',
      admin: true
    }
  ];
  
  return (
    <>
      {/* Mobile overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm md:hidden"
          onClick={closeMenu}
        />
      )}
      
      {/* Sidebar - Mobile + Desktop */}
      <aside className={cn(
        "bg-darker fixed inset-y-0 left-0 z-50 flex w-64 flex-col transition-transform duration-300 ease-in-out md:translate-x-0",
        isMobileOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-4 flex items-center justify-center border-b border-border">
          <Link href="/" className="text-2xl font-bold text-foreground">
            Lucky<span className="text-accent">Play</span>
          </Link>
        </div>
        
        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-2 px-2">
            {navItems.map((item) => (
              <li key={item.id || item.href}>
                <Link href={item.href} onClick={closeMenu}>
                  <Button
                    variant="ghost"
                    className={cn(
                      "w-full justify-start font-medium text-foreground",
                      location === item.href ? "bg-primary text-primary-foreground hover:bg-primary/90" : "hover:bg-muted"
                    )}
                  >
                    {item.icon}
                    {item.title}
                  </Button>
                </Link>
              </li>
            ))}
          </ul>
          
          {user?.isAdmin && (
            <>
              <Separator className="my-4" />
              <div className="px-3 mb-2 text-xs font-semibold text-muted-foreground">
                ADMIN CONTROLS
              </div>
              <ul className="space-y-2 px-2">
                {adminItems.map((item) => (
                  <li key={item.id || item.href}>
                    <Link href={item.href} onClick={closeMenu}>
                      <Button
                        variant="ghost"
                        className={cn(
                          "w-full justify-start font-medium text-foreground",
                          location === item.href ? "bg-primary text-primary-foreground hover:bg-primary/90" : "hover:bg-muted"
                        )}
                      >
                        {item.icon}
                        {item.title}
                      </Button>
                    </Link>
                  </li>
                ))}
              </ul>
            </>
          )}
        </nav>
        
        <div className="p-4 border-t border-border">
          <Button 
            variant="ghost" 
            className="w-full justify-start text-foreground hover:bg-muted"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            <LogOut className="mr-3 h-5 w-5" />
            {logoutMutation.isPending ? "Logging out..." : "Logout"}
          </Button>
        </div>
      </aside>
    </>
  );
}
