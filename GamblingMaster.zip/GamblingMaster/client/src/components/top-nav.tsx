import { useState } from "react";
import { Menu, Search, Plus } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const depositSchema = z.object({
  amount: z.string().refine((val) => {
    const num = parseFloat(val);
    return !isNaN(num) && num > 0;
  }, {
    message: "Amount must be a positive number",
  }),
});

type DepositFormValues = z.infer<typeof depositSchema>;

export default function TopNav({ 
  toggleSidebar 
}: { 
  toggleSidebar: () => void 
}) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDepositOpen, setIsDepositOpen] = useState(false);
  
  const form = useForm<DepositFormValues>({
    resolver: zodResolver(depositSchema),
    defaultValues: {
      amount: "100",
    },
  });
  
  // This would be linked to a real payment processor in production
  const handleDeposit = async (values: DepositFormValues) => {
    try {
      await apiRequest("POST", "/api/wallet/deposit", {
        amount: parseFloat(values.amount)
      });
      
      // Invalidate user query to refresh balance
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      
      toast({
        title: "Deposit successful",
        description: `₹${values.amount} has been added to your account`,
      });
      
      setIsDepositOpen(false);
    } catch (error) {
      toast({
        title: "Deposit failed",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    }
  };

  const userInitials = user?.username ? user.username.substring(0, 2).toUpperCase() : "??";
  
  return (
    <header className="bg-darker py-4 px-4 flex justify-between items-center shadow-md">
      {/* Mobile menu button */}
      <button className="md:hidden text-foreground" onClick={toggleSidebar}>
        <Menu className="h-6 w-6" />
      </button>
      
      {/* Search - visible on larger screens */}
      <div className="hidden md:flex items-center bg-muted rounded-lg px-3 py-2 flex-1 max-w-md mx-4">
        <Search className="h-5 w-5 text-muted-foreground mr-2" />
        <Input 
          type="text" 
          placeholder="Search games..." 
          className="bg-transparent border-0 shadow-none focus-visible:ring-0 focus-visible:ring-offset-0"
        />
      </div>
      
      {/* User wallet and profile */}
      <div className="flex items-center">
        <div className="bg-darkCard rounded-lg px-4 py-2 flex items-center mr-4">
          <Wallet className="h-5 w-5 text-secondary mr-2" />
          <span className="font-medium">₹{parseFloat(user?.balance?.toString() || "0").toLocaleString('en-IN')}</span>
          <Dialog open={isDepositOpen} onOpenChange={setIsDepositOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm" className="ml-2 p-0 h-6 w-6">
                <Plus className="h-4 w-4" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Funds</DialogTitle>
                <DialogDescription>
                  Enter the amount you want to deposit to your account.
                </DialogDescription>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleDeposit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Amount (₹)</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" min="100" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-2">
                    <Button type="button" variant="outline" onClick={() => form.setValue("amount", "100")}>₹100</Button>
                    <Button type="button" variant="outline" onClick={() => form.setValue("amount", "500")}>₹500</Button>
                    <Button type="button" variant="outline" onClick={() => form.setValue("amount", "1000")}>₹1,000</Button>
                    <Button type="button" variant="outline" onClick={() => form.setValue("amount", "5000")}>₹5,000</Button>
                  </div>
                  
                  <DialogFooter>
                    <Button type="submit">Add Funds</Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
        
        <div className="relative">
          <Link href="/profile">
            <Button variant="ghost" className="p-0 h-10 w-10 rounded-full bg-primary flex items-center justify-center text-white">
              {userInitials}
            </Button>
          </Link>
        </div>
      </div>
    </header>
  );
}

// Wallet Icon Component
function Wallet({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4" />
      <path d="M4 6v12c0 1.1.9 2 2 2h14v-4" />
      <path d="M18 12a2 2 0 0 0-2 2c0 1.1.9 2 2 2h4v-4h-4z" />
    </svg>
  );
}
