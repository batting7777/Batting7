import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function LuckyNumber() {
  const [betAmount, setBetAmount] = useState<string>("100");
  const [selectedNumber, setSelectedNumber] = useState<number | null>(null);
  const [gameResult, setGameResult] = useState<any | null>(null);
  const [isRevealing, setIsRevealing] = useState<boolean>(false);
  const [resultNumber, setResultNumber] = useState<number | null>(null);
  const [recentResults, setRecentResults] = useState<{ choice: number, result: number }[]>([]);
  const { toast } = useToast();
  
  const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  
  const placeBetMutation = useMutation({
    mutationFn: async () => {
      if (selectedNumber === null) {
        throw new Error("Please select a number");
      }
      
      if (!betAmount || parseFloat(betAmount) <= 0) {
        throw new Error("Please enter a valid bet amount");
      }
      
      const response = await apiRequest("POST", "/api/games/bet", {
        gameType: "luckyNumber",
        betAmount,
        choice: selectedNumber.toString(),
      });
      
      return await response.json();
    },
    onSuccess: (data) => {
      // Update UI with result
      setGameResult(data);
      
      // Trigger number reveal animation
      const result = data.gameState.result;
      revealNumber(result);
      
      // Add to recent results
      setRecentResults(prev => [{ choice: data.gameState.choice, result }, ...prev].slice(0, 10));
      
      // Refresh user data to update balance
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Bet Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Function to handle number reveal animation
  const revealNumber = (result: number) => {
    setIsRevealing(true);
    
    // Show random numbers rapidly changing before revealing the actual result
    let counter = 0;
    const maxCycles = 20; // Number of rapid changes before settling
    const interval = setInterval(() => {
      const randomNum = Math.floor(Math.random() * 10) + 1;
      setResultNumber(randomNum);
      
      counter++;
      if (counter >= maxCycles) {
        clearInterval(interval);
        setResultNumber(result);
        
        // Show final result
        setTimeout(() => {
          setIsRevealing(false);
        }, 500);
      }
    }, 100);
  };
  
  const handleNumberSelect = (number: number) => {
    if (!isRevealing && !placeBetMutation.isPending) {
      setSelectedNumber(number);
    }
  };
  
  const handlePlaceBet = () => {
    placeBetMutation.mutate();
  };
  
  const handleQuickAmount = (amount: string) => {
    setBetAmount(amount);
  };
  
  // Reset result number when selected number changes
  useEffect(() => {
    setResultNumber(null);
  }, [selectedNumber]);
  
  return (
    <div className="flex flex-col items-center">
      {/* Result number display */}
      <div className="mb-8 flex justify-center">
        {resultNumber !== null ? (
          <div className="number-ball text-4xl font-bold">{resultNumber}</div>
        ) : (
          <div className="number-ball bg-darkCard text-4xl font-bold animate-pulse">?</div>
        )}
      </div>
      
      {/* Number selection grid */}
      <div className="grid grid-cols-5 gap-3 mb-6">
        {numbers.map((number) => (
          <Button
            key={number}
            variant={selectedNumber === number ? 'default' : 'outline'}
            className={cn(
              "h-14 w-14 text-xl font-bold",
              resultNumber === number && "bg-accent text-accent-foreground hover:bg-accent"
            )}
            onClick={() => handleNumberSelect(number)}
            disabled={isRevealing || placeBetMutation.isPending}
          >
            {number}
          </Button>
        ))}
      </div>
      
      {/* Selected number info */}
      <div className="text-center mb-6">
        {selectedNumber !== null ? (
          <p className="text-lg">You selected: <span className="font-bold text-primary">{selectedNumber}</span></p>
        ) : (
          <p className="text-muted-foreground">Select a number between 1 and 10</p>
        )}
      </div>
      
      {/* Bet amount selection */}
      <div className="w-full max-w-md">
        <label className="block text-muted-foreground mb-2">Bet Amount (₹)</label>
        <div className="flex mb-6">
          <Input
            type="number"
            value={betAmount}
            onChange={(e) => setBetAmount(e.target.value)}
            min="10"
            className="rounded-r-none"
            disabled={isRevealing || placeBetMutation.isPending}
          />
          <Button 
            className="rounded-l-none"
            onClick={handlePlaceBet}
            disabled={selectedNumber === null || isRevealing || placeBetMutation.isPending}
          >
            {placeBetMutation.isPending ? "Betting..." : "Bet"}
          </Button>
        </div>
        
        {/* Quick amount selection */}
        <div className="grid grid-cols-4 gap-2 mb-6">
          <Button variant="outline" onClick={() => handleQuickAmount("50")} disabled={isRevealing || placeBetMutation.isPending}>₹50</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("100")} disabled={isRevealing || placeBetMutation.isPending}>₹100</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("500")} disabled={isRevealing || placeBetMutation.isPending}>₹500</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("1000")} disabled={isRevealing || placeBetMutation.isPending}>₹1000</Button>
        </div>
      </div>
      
      {/* Game result */}
      {gameResult && !isRevealing && (
        <div className="bg-darkCard border border-border rounded-lg p-4 w-full max-w-md text-center mb-6">
          <div className="font-bold text-xl mb-2">
            {gameResult.outcome === 'win' ? 'You Won!' : 'You Lost!'}
          </div>
          <div className={gameResult.outcome === 'win' ? 'text-secondary font-bold text-2xl' : 'text-destructive font-bold text-2xl'}>
            {gameResult.outcome === 'win' ? `+₹${gameResult.winAmount}` : `-₹${parseFloat(betAmount)}`}
          </div>
        </div>
      )}
      
      {/* Game history */}
      <div className="w-full">
        <h3 className="font-bold text-lg mb-3">Recent Results</h3>
        <div className="flex overflow-x-auto pb-2 gap-3">
          {recentResults.map((result, index) => (
            <div 
              key={index} 
              className="flex-shrink-0 flex flex-col items-center"
            >
              <div className="number-ball w-10 h-10 text-base">
                {result.result}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Picked {result.choice}
              </div>
            </div>
          ))}
          {recentResults.length === 0 && (
            <div className="text-muted-foreground">No recent results. Start playing!</div>
          )}
        </div>
      </div>
    </div>
  );
}
