import { useState, useRef, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function DiceRoll() {
  const [betAmount, setBetAmount] = useState<string>("100");
  const [selectedNumber, setSelectedNumber] = useState<number | null>(null);
  const [gameResult, setGameResult] = useState<any | null>(null);
  const [isRolling, setIsRolling] = useState<boolean>(false);
  const [recentResults, setRecentResults] = useState<number[]>([]);
  const diceRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  const placeBetMutation = useMutation({
    mutationFn: async () => {
      if (selectedNumber === null) {
        throw new Error("Please select a number");
      }
      
      if (!betAmount || parseFloat(betAmount) <= 0) {
        throw new Error("Please enter a valid bet amount");
      }
      
      const response = await apiRequest("POST", "/api/games/bet", {
        gameType: "diceRoll",
        betAmount,
        choice: selectedNumber.toString(),
      });
      
      return await response.json();
    },
    onSuccess: (data) => {
      // Update UI with result
      setGameResult(data);
      
      // Trigger dice roll animation
      const result = data.gameState.result;
      rollDice(result);
      
      // Add to recent results
      setRecentResults(prev => [result, ...prev].slice(0, 10));
      
      // Refresh user data to update balance
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Bet Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Function to handle dice roll animation
  const rollDice = (outcome: number) => {
    if (diceRef.current) {
      setIsRolling(true);
      
      // Remove previous roll classes
      for (let i = 1; i <= 6; i++) {
        diceRef.current.classList.remove(`roll-${i}`);
      }
      
      // Add random roll animation
      diceRef.current.style.transform = `rotateX(${Math.random() * 360}deg) rotateY(${Math.random() * 360}deg)`;
      
      // After initial random rotation, show the actual result
      setTimeout(() => {
        if (diceRef.current) {
          diceRef.current.style.transform = '';
          diceRef.current.classList.add(`roll-${outcome}`);
          
          // Show result after animation
          setTimeout(() => {
            setIsRolling(false);
          }, 1000);
        }
      }, 1000);
    }
  };
  
  const handlePlaceBet = () => {
    placeBetMutation.mutate();
  };
  
  const handleQuickAmount = (amount: string) => {
    setBetAmount(amount);
  };
  
  return (
    <div className="flex flex-col items-center">
      {/* Dice animation area */}
      <div className="mb-8 flex justify-center">
        <div ref={diceRef} className="dice">
          <div className="dice-face face-1">1</div>
          <div className="dice-face face-2">2</div>
          <div className="dice-face face-3">3</div>
          <div className="dice-face face-4">4</div>
          <div className="dice-face face-5">5</div>
          <div className="dice-face face-6">6</div>
        </div>
      </div>
      
      {/* Number selection */}
      <div className="flex flex-wrap justify-center gap-3 mb-6">
        {[1, 2, 3, 4, 5, 6].map((number) => (
          <Button
            key={number}
            variant={selectedNumber === number ? 'default' : 'outline'}
            className="h-14 w-14 text-xl font-bold"
            onClick={() => setSelectedNumber(number)}
            disabled={isRolling || placeBetMutation.isPending}
          >
            {number}
          </Button>
        ))}
      </div>
      
      {/* Bet amount selection */}
      <div className="w-full max-w-md">
        <label className="block text-muted-foreground mb-2">Bet Amount (₹)</label>
        <div className="flex mb-6">
          <Input
            type="number"
            value={betAmount}
            onChange={(e) => setBetAmount(e.target.value)}
            min="10"
            className="rounded-r-none"
            disabled={isRolling || placeBetMutation.isPending}
          />
          <Button 
            className="rounded-l-none"
            onClick={handlePlaceBet}
            disabled={selectedNumber === null || isRolling || placeBetMutation.isPending}
          >
            {placeBetMutation.isPending ? "Betting..." : "Bet"}
          </Button>
        </div>
        
        {/* Quick amount selection */}
        <div className="grid grid-cols-4 gap-2 mb-6">
          <Button variant="outline" onClick={() => handleQuickAmount("50")} disabled={isRolling || placeBetMutation.isPending}>₹50</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("100")} disabled={isRolling || placeBetMutation.isPending}>₹100</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("500")} disabled={isRolling || placeBetMutation.isPending}>₹500</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("1000")} disabled={isRolling || placeBetMutation.isPending}>₹1000</Button>
        </div>
      </div>
      
      {/* Game result */}
      {gameResult && !isRolling && (
        <div className="bg-darkCard border border-border rounded-lg p-4 w-full max-w-md text-center mb-6">
          <div className="font-bold text-xl mb-2">
            {gameResult.outcome === 'win' ? 'You Won!' : 'You Lost!'}
          </div>
          <div className={gameResult.outcome === 'win' ? 'text-secondary font-bold text-2xl' : 'text-destructive font-bold text-2xl'}>
            {gameResult.outcome === 'win' ? `+₹${gameResult.winAmount}` : `-₹${parseFloat(betAmount)}`}
          </div>
        </div>
      )}
      
      {/* Game history */}
      <div className="w-full">
        <h3 className="font-bold text-lg mb-3">Recent Results</h3>
        <div className="flex overflow-x-auto pb-2 gap-2">
          {recentResults.map((result, index) => (
            <div 
              key={index} 
              className="flex-shrink-0 w-8 h-8 rounded-full bg-darkCard border border-border flex items-center justify-center text-xs font-bold"
            >
              {result}
            </div>
          ))}
          {recentResults.length === 0 && (
            <div className="text-muted-foreground">No recent results. Start playing!</div>
          )}
        </div>
      </div>
    </div>
  );
}
