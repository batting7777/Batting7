import { useState, useRef, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { RotateCw } from "lucide-react";

export default function WheelFortune() {
  const [betAmount, setBetAmount] = useState<string>("100");
  const [gameResult, setGameResult] = useState<any | null>(null);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [recentResults, setRecentResults] = useState<{multiplier: number, index: number}[]>([]);
  const wheelRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  // Wheel segments with multipliers
  const segments = [
    { multiplier: 0, color: "#F44336" },    // Red - lose
    { multiplier: 0.5, color: "#FF9800" },  // Orange - half back
    { multiplier: 1.5, color: "#4CAF50" },  // Green - win 1.5x
    { multiplier: 0, color: "#F44336" },    // Red - lose
    { multiplier: 2, color: "#2196F3" },    // Blue - win 2x
    { multiplier: 0, color: "#F44336" },    // Red - lose
    { multiplier: 3, color: "#9C27B0" },    // Purple - win 3x
    { multiplier: 0, color: "#F44336" }     // Red - lose
  ];
  
  // Create wheel segments on component mount
  useEffect(() => {
    createWheel();
  }, []);
  
  const createWheel = () => {
    if (!wheelRef.current) return;
    
    // Clear any existing segments
    wheelRef.current.innerHTML = '';
    
    // Create wheel pointer
    const pointer = document.createElement('div');
    pointer.className = 'wheel-pointer';
    wheelRef.current.appendChild(pointer);
    
    // Create wheel segments
    segments.forEach((segment, index) => {
      const segmentEl = document.createElement('div');
      segmentEl.className = 'wheel-section';
      segmentEl.style.transform = `rotate(${index * (360 / segments.length)}deg)`;
      segmentEl.style.borderColor = `${segment.color} transparent transparent`;
      
      const label = document.createElement('div');
      label.className = 'absolute text-white text-xs font-bold';
      label.style.left = '0px';
      label.style.top = '55px';
      label.style.transform = 'translateX(-50%) rotate(180deg)';
      label.innerText = segment.multiplier > 0 ? `${segment.multiplier}x` : '0';
      
      segmentEl.appendChild(label);
      wheelRef.current.appendChild(segmentEl);
    });
  };
  
  const placeBetMutation = useMutation({
    mutationFn: async () => {
      if (!betAmount || parseFloat(betAmount) <= 0) {
        throw new Error("Please enter a valid bet amount");
      }
      
      const response = await apiRequest("POST", "/api/games/bet", {
        gameType: "wheelFortune",
        betAmount,
        choice: "spin", // Not used for wheel but required by API
      });
      
      return await response.json();
    },
    onSuccess: (data) => {
      // Update UI with result
      setGameResult(data);
      
      // Trigger wheel spin animation
      const resultIndex = data.gameState.result;
      spinWheel(resultIndex);
      
      // Add to recent results
      setRecentResults(prev => [{
        multiplier: data.gameState.multiplier,
        index: resultIndex
      }, ...prev].slice(0, 10));
      
      // Refresh user data to update balance
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Bet Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Function to handle wheel spin animation
  const spinWheel = (resultIndex: number) => {
    if (wheelRef.current) {
      setIsSpinning(true);
      
      // Calculate the final rotation
      // Each segment is 360 / segments.length degrees
      // We add 2 full rotations (720 degrees) for dramatic effect
      const segmentAngle = 360 / segments.length;
      const rotationAngle = 720 + (resultIndex * segmentAngle);
      
      // Apply the rotation
      wheelRef.current.style.transform = `rotate(${rotationAngle}deg)`;
      
      // Show result after animation
      setTimeout(() => {
        setIsSpinning(false);
      }, 4000);
    }
  };
  
  const handlePlaceBet = () => {
    placeBetMutation.mutate();
  };
  
  const handleQuickAmount = (amount: string) => {
    setBetAmount(amount);
  };
  
  return (
    <div className="flex flex-col items-center">
      {/* Wheel animation area */}
      <div className="mb-8 relative">
        <div 
          ref={wheelRef} 
          className="wheel" 
          style={{ transition: "transform 4s cubic-bezier(0.2, 0.8, 0.25, 1)" }}
        >
          {/* Segments will be created by JavaScript */}
        </div>
      </div>
      
      {/* Bet amount selection */}
      <div className="w-full max-w-md">
        <label className="block text-muted-foreground mb-2">Bet Amount (₹)</label>
        <div className="flex mb-6">
          <Input
            type="number"
            value={betAmount}
            onChange={(e) => setBetAmount(e.target.value)}
            min="10"
            className="rounded-r-none"
            disabled={isSpinning || placeBetMutation.isPending}
          />
          <Button 
            className="rounded-l-none"
            onClick={handlePlaceBet}
            disabled={isSpinning || placeBetMutation.isPending}
          >
            {placeBetMutation.isPending ? (
              <>Betting...</>
            ) : (
              <>
                <RotateCw className="mr-2 h-4 w-4" />
                Spin
              </>
            )}
          </Button>
        </div>
        
        {/* Quick amount selection */}
        <div className="grid grid-cols-4 gap-2 mb-6">
          <Button variant="outline" onClick={() => handleQuickAmount("50")} disabled={isSpinning || placeBetMutation.isPending}>₹50</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("100")} disabled={isSpinning || placeBetMutation.isPending}>₹100</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("500")} disabled={isSpinning || placeBetMutation.isPending}>₹500</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("1000")} disabled={isSpinning || placeBetMutation.isPending}>₹1000</Button>
        </div>
      </div>
      
      {/* Game result */}
      {gameResult && !isSpinning && (
        <div className="bg-darkCard border border-border rounded-lg p-4 w-full max-w-md text-center mb-6">
          <div className="font-bold text-xl mb-2">
            {gameResult.outcome === 'win' ? 'You Won!' : 'You Lost!'}
          </div>
          <div className={gameResult.outcome === 'win' ? 'text-secondary font-bold text-2xl' : 'text-destructive font-bold text-2xl'}>
            {gameResult.outcome === 'win' ? `+₹${gameResult.winAmount}` : `-₹${parseFloat(betAmount)}`}
          </div>
        </div>
      )}
      
      {/* Game history */}
      <div className="w-full">
        <h3 className="font-bold text-lg mb-3">Recent Results</h3>
        <div className="flex overflow-x-auto pb-2 gap-2">
          {recentResults.map((result, index) => {
            const segment = segments[result.index];
            return (
              <div 
                key={index} 
                className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white"
                style={{ backgroundColor: segment.color }}
              >
                {result.multiplier}x
              </div>
            );
          })}
          {recentResults.length === 0 && (
            <div className="text-muted-foreground">No recent results. Start playing!</div>
          )}
        </div>
      </div>
    </div>
  );
}
