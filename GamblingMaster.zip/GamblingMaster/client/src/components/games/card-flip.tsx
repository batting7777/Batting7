import { useState, useRef, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function CardFlip() {
  const [betAmount, setBetAmount] = useState<string>("100");
  const [selectedCard, setSelectedCard] = useState<string | null>(null);
  const [gameResult, setGameResult] = useState<any | null>(null);
  const [isFlipping, setIsFlipping] = useState<boolean>(false);
  const [flippedCard, setFlippedCard] = useState<string | null>(null);
  const [recentResults, setRecentResults] = useState<{ choice: string, result: string }[]>([]);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const { toast } = useToast();
  
  const cards = ["A", "K", "Q", "J"];
  
  const placeBetMutation = useMutation({
    mutationFn: async () => {
      if (!selectedCard) {
        throw new Error("Please select a card");
      }
      
      if (!betAmount || parseFloat(betAmount) <= 0) {
        throw new Error("Please enter a valid bet amount");
      }
      
      const response = await apiRequest("POST", "/api/games/bet", {
        gameType: "cardFlip",
        betAmount,
        choice: selectedCard,
      });
      
      return await response.json();
    },
    onSuccess: (data) => {
      // Update UI with result
      setGameResult(data);
      
      // Trigger card flip animation
      const result = data.gameState.result;
      setFlippedCard(result);
      
      // Add to recent results
      setRecentResults(prev => [{ choice: data.gameState.choice, result }, ...prev].slice(0, 10));
      
      // Refresh user data to update balance
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Bet Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Reset card flipping state when selecting a new card
  useEffect(() => {
    if (selectedCard && !isFlipping) {
      // Reset all cards
      cardsRef.current.forEach((cardEl) => {
        if (cardEl) {
          cardEl.querySelector('.card-inner')?.classList.remove('flipped');
        }
      });
      setFlippedCard(null);
    }
  }, [selectedCard]);
  
  // Handle card flip animation after getting result
  useEffect(() => {
    if (flippedCard && !isFlipping) {
      setIsFlipping(true);
      
      // Flip all cards after a short delay
      setTimeout(() => {
        cardsRef.current.forEach((cardEl) => {
          if (cardEl) {
            const cardInner = cardEl.querySelector('.card-inner');
            cardInner?.classList.add('flipped');
          }
        });
        
        // Set flipping to false after animation completes
        setTimeout(() => {
          setIsFlipping(false);
        }, 1000);
      }, 500);
    }
  }, [flippedCard]);
  
  const handleCardSelect = (card: string) => {
    if (!isFlipping && !placeBetMutation.isPending) {
      setSelectedCard(card);
    }
  };
  
  const handlePlaceBet = () => {
    placeBetMutation.mutate();
  };
  
  const handleQuickAmount = (amount: string) => {
    setBetAmount(amount);
  };
  
  return (
    <div className="flex flex-col items-center">
      {/* Cards display area */}
      <div className="mb-8 flex justify-center flex-wrap gap-4">
        {cards.map((card, index) => (
          <div
            key={card}
            ref={el => cardsRef.current[index] = el}
            className={`card ${selectedCard === card ? 'ring-2 ring-primary ring-offset-2 ring-offset-background' : ''}`}
            onClick={() => handleCardSelect(card)}
          >
            <div className="card-inner">
              <div className="card-front">{card}</div>
              <div className="card-back">
                {flippedCard === card ? card : "?"}
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Selected card info */}
      <div className="text-center mb-6">
        {selectedCard ? (
          <p className="text-lg">You selected: <span className="font-bold text-primary">{selectedCard}</span></p>
        ) : (
          <p className="text-muted-foreground">Select a card to bet on</p>
        )}
      </div>
      
      {/* Bet amount selection */}
      <div className="w-full max-w-md">
        <label className="block text-muted-foreground mb-2">Bet Amount (₹)</label>
        <div className="flex mb-6">
          <Input
            type="number"
            value={betAmount}
            onChange={(e) => setBetAmount(e.target.value)}
            min="10"
            className="rounded-r-none"
            disabled={isFlipping || placeBetMutation.isPending}
          />
          <Button 
            className="rounded-l-none"
            onClick={handlePlaceBet}
            disabled={!selectedCard || isFlipping || placeBetMutation.isPending}
          >
            {placeBetMutation.isPending ? "Betting..." : "Bet"}
          </Button>
        </div>
        
        {/* Quick amount selection */}
        <div className="grid grid-cols-4 gap-2 mb-6">
          <Button variant="outline" onClick={() => handleQuickAmount("50")} disabled={isFlipping || placeBetMutation.isPending}>₹50</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("100")} disabled={isFlipping || placeBetMutation.isPending}>₹100</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("500")} disabled={isFlipping || placeBetMutation.isPending}>₹500</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("1000")} disabled={isFlipping || placeBetMutation.isPending}>₹1000</Button>
        </div>
      </div>
      
      {/* Game result */}
      {gameResult && !isFlipping && (
        <div className="bg-darkCard border border-border rounded-lg p-4 w-full max-w-md text-center mb-6">
          <div className="font-bold text-xl mb-2">
            {gameResult.outcome === 'win' ? 'You Won!' : 'You Lost!'}
          </div>
          <div className={gameResult.outcome === 'win' ? 'text-secondary font-bold text-2xl' : 'text-destructive font-bold text-2xl'}>
            {gameResult.outcome === 'win' ? `+₹${gameResult.winAmount}` : `-₹${parseFloat(betAmount)}`}
          </div>
        </div>
      )}
      
      {/* Game history */}
      <div className="w-full">
        <h3 className="font-bold text-lg mb-3">Recent Results</h3>
        <div className="flex overflow-x-auto pb-2 gap-3">
          {recentResults.map((result, index) => (
            <div 
              key={index} 
              className="flex-shrink-0 flex flex-col items-center"
            >
              <div className="w-10 h-14 bg-darkCard border border-border rounded-md flex items-center justify-center font-bold mb-1">
                {result.result}
              </div>
              <div className="text-xs text-muted-foreground">
                Picked {result.choice}
              </div>
            </div>
          ))}
          {recentResults.length === 0 && (
            <div className="text-muted-foreground">No recent results. Start playing!</div>
          )}
        </div>
      </div>
    </div>
  );
}
