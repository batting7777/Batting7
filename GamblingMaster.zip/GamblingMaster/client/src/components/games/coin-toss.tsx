import { useState, useRef, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ArrowUpCircle, ArrowDownCircle } from "lucide-react";

export default function CoinToss() {
  const [betAmount, setBetAmount] = useState<string>("100");
  const [selectedSide, setSelectedSide] = useState<string | null>(null);
  const [gameResult, setGameResult] = useState<any | null>(null);
  const [isFlipping, setIsFlipping] = useState<boolean>(false);
  const [recentResults, setRecentResults] = useState<string[]>([]);
  const coinRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  const placeBetMutation = useMutation({
    mutationFn: async () => {
      if (!selectedSide) {
        throw new Error("Please select heads or tails");
      }
      
      if (!betAmount || parseFloat(betAmount) <= 0) {
        throw new Error("Please enter a valid bet amount");
      }
      
      const response = await apiRequest("POST", "/api/games/bet", {
        gameType: "coinToss",
        betAmount,
        choice: selectedSide,
      });
      
      return await response.json();
    },
    onSuccess: (data) => {
      // Update UI with result
      setGameResult(data);
      
      // Trigger coin flip animation
      const result = data.gameState.result;
      flipCoin(result);
      
      // Add to recent results
      setRecentResults(prev => [result === 'heads' ? 'H' : 'T', ...prev].slice(0, 10));
      
      // Refresh user data to update balance
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Bet Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Function to handle coin flip animation
  const flipCoin = (outcome: string) => {
    if (coinRef.current) {
      setIsFlipping(true);
      
      // Remove previous flip classes
      coinRef.current.classList.remove('flip-heads', 'flip-tails');
      
      // Force a reflow
      void coinRef.current.offsetWidth;
      
      // Add the appropriate class
      coinRef.current.classList.add(outcome === 'heads' ? 'flip-heads' : 'flip-tails');
      
      // Show result after animation
      setTimeout(() => {
        setIsFlipping(false);
      }, 3000);
    }
  };
  
  const handlePlaceBet = () => {
    placeBetMutation.mutate();
  };
  
  const handleQuickAmount = (amount: string) => {
    setBetAmount(amount);
  };
  
  return (
    <div className="flex flex-col items-center">
      {/* Coin animation area */}
      <div className="mb-8 flex justify-center">
        <div ref={coinRef} className="coin">
          <div className="coin-front font-bold text-xl">Heads</div>
          <div className="coin-back font-bold text-xl">Tails</div>
        </div>
      </div>
      
      {/* Betting options */}
      <div className="flex flex-wrap justify-center gap-4 mb-6">
        <Button
          variant={selectedSide === 'heads' ? 'default' : 'outline'}
          className="py-6 px-8 text-lg"
          onClick={() => setSelectedSide('heads')}
          disabled={isFlipping || placeBetMutation.isPending}
        >
          <ArrowUpCircle className="mr-2 h-5 w-5" />
          Heads
        </Button>
        <Button
          variant={selectedSide === 'tails' ? 'default' : 'outline'}
          className="py-6 px-8 text-lg"
          onClick={() => setSelectedSide('tails')}
          disabled={isFlipping || placeBetMutation.isPending}
        >
          <ArrowDownCircle className="mr-2 h-5 w-5" />
          Tails
        </Button>
      </div>
      
      {/* Bet amount selection */}
      <div className="w-full max-w-md">
        <label className="block text-muted-foreground mb-2">Bet Amount (₹)</label>
        <div className="flex mb-6">
          <Input
            type="number"
            value={betAmount}
            onChange={(e) => setBetAmount(e.target.value)}
            min="10"
            className="rounded-r-none"
            disabled={isFlipping || placeBetMutation.isPending}
          />
          <Button 
            className="rounded-l-none"
            onClick={handlePlaceBet}
            disabled={!selectedSide || isFlipping || placeBetMutation.isPending}
          >
            {placeBetMutation.isPending ? "Betting..." : "Bet"}
          </Button>
        </div>
        
        {/* Quick amount selection */}
        <div className="grid grid-cols-4 gap-2 mb-6">
          <Button variant="outline" onClick={() => handleQuickAmount("50")} disabled={isFlipping || placeBetMutation.isPending}>₹50</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("100")} disabled={isFlipping || placeBetMutation.isPending}>₹100</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("500")} disabled={isFlipping || placeBetMutation.isPending}>₹500</Button>
          <Button variant="outline" onClick={() => handleQuickAmount("1000")} disabled={isFlipping || placeBetMutation.isPending}>₹1000</Button>
        </div>
      </div>
      
      {/* Game result */}
      {gameResult && !isFlipping && (
        <div className="bg-darkCard border border-border rounded-lg p-4 w-full max-w-md text-center mb-6">
          <div className="font-bold text-xl mb-2">
            {gameResult.outcome === 'win' ? 'You Won!' : 'You Lost!'}
          </div>
          <div className={gameResult.outcome === 'win' ? 'text-secondary font-bold text-2xl' : 'text-destructive font-bold text-2xl'}>
            {gameResult.outcome === 'win' ? `+₹${gameResult.winAmount}` : `-₹${parseFloat(betAmount)}`}
          </div>
        </div>
      )}
      
      {/* Game history */}
      <div className="w-full">
        <h3 className="font-bold text-lg mb-3">Recent Results</h3>
        <div className="flex overflow-x-auto pb-2 gap-2">
          {recentResults.map((result, index) => (
            <div 
              key={index} 
              className={`flex-shrink-0 w-8 h-8 rounded-full ${result === 'H' ? 'bg-secondary' : 'bg-destructive'} flex items-center justify-center text-xs font-medium`}
            >
              {result}
            </div>
          ))}
          {recentResults.length === 0 && (
            <div className="text-muted-foreground">No recent results. Start playing!</div>
          )}
        </div>
      </div>
    </div>
  );
}
