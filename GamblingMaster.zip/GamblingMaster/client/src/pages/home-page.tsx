import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import TopNav from "@/components/top-nav";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Coins, 
  Dice5, 
  RotateCw, 
  CreditCard, 
  Hash,
  Share2, 
  Copy, 
  ExternalLink 
} from "lucide-react";
import { GameHistory, Transaction } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";

export default function HomePage() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };
  
  // Fetch recent game history
  const { data: gameHistory } = useQuery<GameHistory[]>({
    queryKey: ["/api/games/history"],
    select: (data) => data.slice(0, 5), // Get only the 5 most recent games
  });
  
  // Fetch user transactions
  const { data: transactions } = useQuery<Transaction[]>({
    queryKey: ["/api/wallet/transactions"],
    select: (data) => data.slice(0, 5), // Get only the 5 most recent transactions
  });
  
  const copyReferralCode = () => {
    if (user?.referralCode) {
      navigator.clipboard.writeText(user.referralCode);
      toast({
        title: "Referral code copied",
        description: "Share this code with your friends to earn bonuses!"
      });
    }
  };
  
  const games = [
    {
      id: "coinToss",
      name: "Coin Toss",
      description: "Heads or Tails?",
      icon: <Coins className="h-16 w-16 text-white" />,
      gradient: "from-primary to-accent"
    },
    {
      id: "diceRoll",
      name: "Dice5 Roll",
      description: "Bet on 1-6",
      icon: <Dice5 className="h-16 w-16 text-white" />,
      gradient: "from-secondary to-primary"
    },
    {
      id: "wheelFortune",
      name: "Wheel of Fortune",
      description: "Spin to win",
      icon: <RotateCw className="h-16 w-16 text-white" />,
      gradient: "from-accent to-secondary"
    },
    {
      id: "cardFlip",
      name: "Card Flip",
      description: "Choose your card",
      icon: <CreditCard className="h-16 w-16 text-white" />,
      gradient: "from-primary to-[#B819E2]"
    },
    {
      id: "luckyNumber",
      name: "Lucky Number",
      description: "Pick 1-10",
      icon: <Hash className="h-16 w-16 text-white" />,
      gradient: "from-[#FF9100] to-[#FFD700]"
    }
  ];
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar isMobileOpen={isMobileOpen} setIsMobileOpen={setIsMobileOpen} />
      
      <main className="flex-1 md:ml-64">
        <TopNav toggleSidebar={toggleSidebar} />
        
        <div className="p-4 md:p-6">
          {/* Welcome Section */}
          <section className="mb-8">
            <Card>
              <CardContent className="p-6 flex flex-col md:flex-row items-center justify-between">
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold mb-2">Welcome back, {user?.username}!</h1>
                  <p className="text-muted-foreground">Ready to test your luck today?</p>
                </div>
                <div className="mt-4 md:mt-0 flex gap-3">
                  <Link href="/wallet">
                    <Button>
                      Deposit
                    </Button>
                  </Link>
                  <Link href="/wallet">
                    <Button variant="outline">
                      Withdraw
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </section>
          
          {/* Games Section */}
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Popular Games</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
              {games.map((game) => (
                <div 
                  key={game.id}
                  className="game-card bg-darkCard rounded-xl overflow-hidden hover:shadow-lg cursor-pointer"
                  onClick={() => navigate(`/game/${game.id}`)}
                >
                  <div className={`h-40 bg-gradient-to-br ${game.gradient} flex items-center justify-center`}>
                    {game.icon}
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-lg mb-1">{game.name}</h3>
                    <p className="text-muted-foreground text-sm mb-3">{game.description}</p>
                    <Button className="w-full" onClick={() => navigate(`/game/${game.id}`)}>
                      Play Now
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </section>
          
          {/* Recent Activity and Refer & Earn */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent Activity */}
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-bold mb-4">Recent Activity</h2>
              <Card>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-4 font-medium">Game</th>
                        <th className="text-left py-3 px-4 font-medium">Time</th>
                        <th className="text-left py-3 px-4 font-medium">Bet</th>
                        <th className="text-left py-3 px-4 font-medium">Result</th>
                      </tr>
                    </thead>
                    <tbody>
                      {gameHistory && gameHistory.length > 0 ? (
                        gameHistory.map((game) => (
                          <tr key={game.id} className="border-b border-border hover:bg-muted/30">
                            <td className="py-3 px-4">{game.gameType}</td>
                            <td className="py-3 px-4 text-muted-foreground">
                              {formatDistanceToNow(new Date(game.createdAt), { addSuffix: true })}
                            </td>
                            <td className="py-3 px-4">₹{parseFloat(game.betAmount.toString()).toFixed(2)}</td>
                            <td className="py-3 px-4">
                              {game.outcome === "win" ? (
                                <span className="text-secondary font-medium">+₹{parseFloat(game.winAmount.toString()).toFixed(2)}</span>
                              ) : (
                                <span className="text-destructive font-medium">-₹{parseFloat(game.betAmount.toString()).toFixed(2)}</span>
                              )}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={4} className="py-6 text-center text-muted-foreground">
                            No recent games. Start playing to see your activity here!
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
                {gameHistory && gameHistory.length > 0 && (
                  <div className="p-4 text-center">
                    <Link href="/history">
                      <Button variant="ghost" size="sm">
                        View All History <ExternalLink className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                )}
              </Card>
            </div>
            
            {/* Refer & Earn */}
            <div>
              <h2 className="text-2xl font-bold mb-4">Refer & Earn</h2>
              <Card className="bg-gradient-to-r from-primary to-[#B819E2]">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-2 mb-3">
                    <Share2 className="h-5 w-5 mt-1 text-white" />
                    <h3 className="text-xl font-bold text-white">Refer & Earn Bonus Cash</h3>
                  </div>
                  
                  <p className="text-white/90 mb-4">Share your referral code with friends and earn bonus when they sign up!</p>
                  
                  <div className="bg-white bg-opacity-20 rounded-lg p-3 flex items-center justify-between mb-4">
                    <span className="text-white font-medium">{user?.referralCode || "Loading..."}</span>
                    <Button 
                      size="sm" 
                      variant="secondary" 
                      className="text-primary"
                      onClick={copyReferralCode}
                    >
                      <Copy className="h-4 w-4 mr-1" /> Copy
                    </Button>
                  </div>
                  
                  <Separator className="bg-white/20 my-4" />
                  
                  <div className="text-white">
                    <div className="font-semibold mb-1">Your Referral Stats</div>
                    <div className="flex justify-between items-center">
                      <span>Referral earnings:</span>
                      <span className="font-bold">₹{parseFloat(user?.referralBalance?.toString() || "0").toFixed(2)}</span>
                    </div>
                  </div>
                  
                  <Link href="/referral">
                    <Button className="w-full mt-4 bg-white text-primary hover:bg-white/90">
                      Invite Friends
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
