import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import Sidebar from "@/components/sidebar";
import TopNav from "@/components/top-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import CoinToss from "@/components/games/coin-toss";
import DiceRoll from "@/components/games/dice-roll";
import WheelFortune from "@/components/games/wheel-fortune";
import CardFlip from "@/components/games/card-flip";
import LuckyNumber from "@/components/games/lucky-number";

export default function GamePage() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { gameType } = useParams();
  const [, navigate] = useLocation();
  
  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };
  
  // Game titles and components mapping
  const gameComponents: Record<string, { title: string, component: React.ComponentType }> = {
    coinToss: { title: "Coin Toss", component: CoinToss },
    diceRoll: { title: "Dice Roll", component: DiceRoll },
    wheelFortune: { title: "Wheel of Fortune", component: WheelFortune },
    cardFlip: { title: "Card Flip", component: CardFlip },
    luckyNumber: { title: "Lucky Number", component: LuckyNumber }
  };
  
  // Redirect to home if game type is invalid
  useEffect(() => {
    if (gameType && !gameComponents[gameType]) {
      navigate("/");
    }
  }, [gameType, navigate]);
  
  if (!gameType || !gameComponents[gameType]) {
    return null;
  }
  
  const { title, component: GameComponent } = gameComponents[gameType];
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar isMobileOpen={isMobileOpen} toggleSidebar={toggleSidebar} />
      
      <main className="flex-1 md:ml-64">
        <TopNav toggleSidebar={toggleSidebar} />
        
        <div className="p-4 md:p-6">
          <section className="mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold">{title}</h2>
                  <Button 
                    variant="ghost"
                    size="icon"
                    className="text-muted-foreground hover:text-foreground"
                    onClick={() => navigate("/")}
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>
                
                {/* Game container */}
                <div className="flex flex-col items-center">
                  <GameComponent />
                </div>
              </CardContent>
            </Card>
          </section>
        </div>
      </main>
    </div>
  );
}
