import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow, format } from "date-fns";
import Sidebar from "@/components/sidebar";
import TopNav from "@/components/top-nav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GameHistory, Transaction } from "@shared/schema";
import { RotateCw, Search, CreditCard, ArrowDownCircle, Filter } from "lucide-react";

export default function HistoryPage() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [gameFilter, setGameFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState<string>("");
  
  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };
  
  // Fetch game history
  const { data: gameHistory, isLoading: isLoadingGames } = useQuery<GameHistory[]>({
    queryKey: ["/api/games/history"],
  });
  
  // Fetch transactions
  const { data: transactions, isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/wallet/transactions"],
  });
  
  // Filter and search game history
  const filteredGames = gameHistory?.filter(game => {
    // Apply game type filter
    if (gameFilter !== "all" && game.gameType !== gameFilter) {
      return false;
    }
    
    // Apply search filter (search in game type and outcome)
    if (searchTerm && !game.gameType.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !game.outcome.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    return true;
  });
  
  // Filter and search transactions
  const filteredTransactions = transactions?.filter(transaction => {
    // Apply search filter (search in type, status, and notes)
    if (searchTerm && 
        !transaction.type.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !transaction.status.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !(transaction.notes && transaction.notes.toLowerCase().includes(searchTerm.toLowerCase()))) {
      return false;
    }
    
    return true;
  });
  
  const getGameTypeIcon = (gameType: string) => {
    switch (gameType) {
      case "coinToss":
        return "🪙";
      case "diceRoll":
        return "🎲";
      case "wheelFortune":
        return "🎡";
      case "cardFlip":
        return "🃏";
      case "luckyNumber":
        return "🔢";
      default:
        return "🎮";
    }
  };
  
  const getTransactionTypeIcon = (type: string) => {
    switch (type) {
      case "win":
        return <CreditCard className="h-5 w-5 text-secondary" />;
      case "loss":
        return <CreditCard className="h-5 w-5 text-destructive" />;
      case "deposit":
        return <ArrowDownCircle className="h-5 w-5 text-secondary" />;
      case "withdrawal":
        return <ArrowDownCircle className="h-5 w-5 text-yellow-500 rotate-180" />;
      case "referral":
        return <RotateCw className="h-5 w-5 text-accent" />;
      default:
        return <CreditCard className="h-5 w-5" />;
    }
  };
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar isMobileOpen={isMobileOpen} toggleSidebar={toggleSidebar} />
      
      <main className="flex-1 md:ml-64">
        <TopNav toggleSidebar={toggleSidebar} />
        
        <div className="p-4 md:p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Activity History</h1>
            <p className="text-muted-foreground">View and search your game and transaction history.</p>
          </div>
          
          <Tabs defaultValue="games" className="space-y-4">
            <TabsList className="w-full max-w-md grid grid-cols-2">
              <TabsTrigger value="games">Game History</TabsTrigger>
              <TabsTrigger value="transactions">Transactions</TabsTrigger>
            </TabsList>
            
            {/* Games Tab */}
            <TabsContent value="games">
              <Card>
                <CardHeader>
                  <CardTitle>Game History</CardTitle>
                  <CardDescription>View your past games, bets, and outcomes.</CardDescription>
                  
                  <div className="mt-4 flex flex-col sm:flex-row gap-4">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search games..."
                        className="pl-9"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <div className="sm:w-48">
                      <Select value={gameFilter} onValueChange={setGameFilter}>
                        <SelectTrigger>
                          <Filter className="mr-2 h-4 w-4" />
                          <SelectValue placeholder="Filter by game" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Games</SelectItem>
                          <SelectItem value="coinToss">Coin Toss</SelectItem>
                          <SelectItem value="diceRoll">Dice Roll</SelectItem>
                          <SelectItem value="wheelFortune">Wheel of Fortune</SelectItem>
                          <SelectItem value="cardFlip">Card Flip</SelectItem>
                          <SelectItem value="luckyNumber">Lucky Number</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {isLoadingGames ? (
                    <div className="flex justify-center py-8">
                      <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : filteredGames && filteredGames.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-border">
                            <th className="text-left py-3 px-4 font-medium">Game</th>
                            <th className="text-left py-3 px-4 font-medium">Time</th>
                            <th className="text-left py-3 px-4 font-medium">Bet</th>
                            <th className="text-left py-3 px-4 font-medium">Outcome</th>
                            <th className="text-left py-3 px-4 font-medium">Result</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredGames.map((game) => (
                            <tr key={game.id} className="border-b border-border hover:bg-muted/30">
                              <td className="py-3 px-4">
                                <div className="flex items-center">
                                  <span className="mr-2">{getGameTypeIcon(game.gameType)}</span>
                                  <span>{game.gameType}</span>
                                </div>
                              </td>
                              <td className="py-3 px-4 text-muted-foreground">
                                <div className="flex flex-col">
                                  <span>{format(new Date(game.createdAt), "MMM d, yyyy")}</span>
                                  <span className="text-xs">{format(new Date(game.createdAt), "h:mm a")}</span>
                                </div>
                              </td>
                              <td className="py-3 px-4">₹{parseFloat(game.betAmount.toString()).toFixed(2)}</td>
                              <td className="py-3 px-4">
                                <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                                  game.outcome === "win" 
                                    ? "bg-secondary/20 text-secondary"
                                    : "bg-destructive/20 text-destructive"
                                }`}>
                                  {game.outcome.toUpperCase()}
                                </span>
                              </td>
                              <td className="py-3 px-4">
                                {game.outcome === "win" ? (
                                  <span className="text-secondary font-medium">+₹{parseFloat(game.winAmount.toString()).toFixed(2)}</span>
                                ) : (
                                  <span className="text-destructive font-medium">-₹{parseFloat(game.betAmount.toString()).toFixed(2)}</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-10 text-muted-foreground">
                      <p>No game history found.</p>
                      <p className="text-sm mt-1">Start playing games to build your history.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Transactions Tab */}
            <TabsContent value="transactions">
              <Card>
                <CardHeader>
                  <CardTitle>Transaction History</CardTitle>
                  <CardDescription>View your financial transactions, deposits, withdrawals, and game results.</CardDescription>
                  
                  <div className="mt-4 relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search transactions..."
                      className="pl-9"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </CardHeader>
                <CardContent>
                  {isLoadingTransactions ? (
                    <div className="flex justify-center py-8">
                      <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : filteredTransactions && filteredTransactions.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-border">
                            <th className="text-left py-3 px-4 font-medium">Type</th>
                            <th className="text-left py-3 px-4 font-medium">Date</th>
                            <th className="text-left py-3 px-4 font-medium">Amount</th>
                            <th className="text-left py-3 px-4 font-medium">Status</th>
                            <th className="text-left py-3 px-4 font-medium">Notes</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredTransactions.map((transaction) => (
                            <tr key={transaction.id} className="border-b border-border hover:bg-muted/30">
                              <td className="py-3 px-4">
                                <div className="flex items-center">
                                  {getTransactionTypeIcon(transaction.type)}
                                  <span className="ml-2 capitalize">{transaction.type}</span>
                                </div>
                              </td>
                              <td className="py-3 px-4 text-muted-foreground">
                                <div className="flex flex-col">
                                  <span>{format(new Date(transaction.createdAt), "MMM d, yyyy")}</span>
                                  <span className="text-xs">{format(new Date(transaction.createdAt), "h:mm a")}</span>
                                </div>
                              </td>
                              <td className="py-3 px-4">
                                <span className={
                                  transaction.type === "win" || transaction.type === "deposit" || transaction.type === "referral"
                                    ? "text-secondary"
                                    : transaction.type === "loss" ? "text-destructive" : ""
                                }>
                                  {transaction.type === "win" || transaction.type === "deposit" || transaction.type === "referral"
                                    ? `+₹${parseFloat(transaction.amount.toString()).toFixed(2)}`
                                    : `-₹${parseFloat(transaction.amount.toString()).toFixed(2)}`
                                  }
                                </span>
                              </td>
                              <td className="py-3 px-4">
                                <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                                  transaction.status === "completed" 
                                    ? "bg-secondary/20 text-secondary"
                                    : transaction.status === "pending"
                                    ? "bg-yellow-500/20 text-yellow-500"
                                    : "bg-destructive/20 text-destructive"
                                }`}>
                                  {transaction.status.toUpperCase()}
                                </span>
                              </td>
                              <td className="py-3 px-4 text-muted-foreground">
                                {transaction.notes || "-"}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-10 text-muted-foreground">
                      <p>No transaction history found.</p>
                      <p className="text-sm mt-1">Your financial transactions will appear here.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
