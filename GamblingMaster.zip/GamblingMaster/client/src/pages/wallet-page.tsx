import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import TopNav from "@/components/top-nav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { Transaction, WithdrawalRequest, DepositRequest, SystemSettings } from "@shared/schema";
import { Wallet, CreditCard, ArrowDownCircle, ArrowUpCircle, RotateCw, QrCode, IndianRupee, Coins } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const withdrawalSchema = z.object({
  amount: z.string().refine((val) => {
    const num = parseFloat(val);
    return !isNaN(num) && num > 0;
  }, {
    message: "Amount must be a positive number",
  }),
  utrNumber: z.string().optional()
});

// Define the deposit schema for form validation
const depositSchema = z.object({
  method: z.enum(["upi", "usdt"], {
    required_error: "Please select a deposit method",
  }),
  amount: z.string().refine((val) => {
    const num = parseFloat(val);
    return !isNaN(num) && num > 0;
  }, {
    message: "Amount must be a positive number",
  }).refine((val) => {
    const num = parseFloat(val);
    // If UPI, check against max limit (30000)
    if (num > 30000) {
      return false;
    }
    return true;
  }, {
    message: "UPI deposits cannot exceed ₹30,000",
  }),
  utrNumber: z.string()
    .optional()
    .superRefine((val, ctx) => {
      // Only validate if value is provided
      if (val && val.length > 12) {
        ctx.addIssue({
          code: z.ZodIssueCode.too_big,
          maximum: 12,
          type: "string",
          inclusive: true,
          message: "UTR number cannot exceed 12 digits",
        });
      }
      return true;
    }),
  walletAddress: z.string().optional(),
  screenshotUrl: z.string().optional(),
});

type WithdrawalFormValues = z.infer<typeof withdrawalSchema>;
type DepositFormValues = z.infer<typeof depositSchema>;

export default function WalletPage() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);
  const [depositMethod, setDepositMethod] = useState<"upi" | "usdt" | null>(null);
  const [depositStep, setDepositStep] = useState<"form" | "payment">("form");
  const [depositAmount, setDepositAmount] = useState<string>("");
  
  const { user } = useAuth();
  const { toast } = useToast();
  
  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };
  
  // Fetch transactions
  const { data: transactions, isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/wallet/transactions"],
  });
  
  // Fetch withdrawal requests
  const { data: withdrawals, isLoading: isLoadingWithdrawals } = useQuery<WithdrawalRequest[]>({
    queryKey: ["/api/wallet/withdrawals"],
  });
  
  // Fetch deposit requests
  const { data: deposits, isLoading: isLoadingDeposits } = useQuery<DepositRequest[]>({
    queryKey: ["/api/wallet/deposits"],
  });
  
  // Fetch system settings for withdrawal limits
  const { data: settings } = useQuery<SystemSettings>({
    queryKey: ["/api/settings"],
  });
  
  const depositForm = useForm<DepositFormValues>({
    resolver: zodResolver(depositSchema),
    defaultValues: {
      method: "upi",
      amount: "",
      utrNumber: "",
      walletAddress: "",
      screenshotUrl: "",
    },
  });
  
  const depositMutation = useMutation({
    mutationFn: async (values: DepositFormValues) => {
      const response = await apiRequest("POST", "/api/wallet/deposit-request", values);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Deposit request submitted",
        description: "Your deposit request has been submitted for approval",
      });
      
      // Reset form
      depositForm.reset();
      setIsDepositModalOpen(false);
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/deposits"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/transactions"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Deposit request failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onDepositSubmit = (values: DepositFormValues) => {
    if (values.method === "upi" && !values.utrNumber) {
      // If UPI but no UTR, show QR code and collect UTR
      setDepositMethod(values.method);
      setDepositAmount(values.amount);
      setDepositStep("payment");
      setIsQrModalOpen(true);
      return;
    }
    
    // Otherwise submit the form directly
    depositMutation.mutate(values);
  };
  
  const handlePaymentComplete = (utrNumber: string) => {
    // Get current form values
    const currentValues = depositForm.getValues();
    
    // Update UTR number and submit
    depositMutation.mutate({
      ...currentValues,
      utrNumber
    });
    
    // Close modal
    setIsQrModalOpen(false);
    setDepositStep("form");
  };
  
  const form = useForm<WithdrawalFormValues>({
    resolver: zodResolver(withdrawalSchema),
    defaultValues: {
      amount: "",
      utrNumber: ""
    },
  });
  
  const withdrawMutation = useMutation({
    mutationFn: async (values: WithdrawalFormValues) => {
      const response = await apiRequest("POST", "/api/wallet/withdraw", values);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Withdrawal request submitted",
        description: "Your withdrawal request has been submitted for approval",
      });
      
      // Reset form
      form.reset();
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/withdrawals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/transactions"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Withdrawal request failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: WithdrawalFormValues) => {
    withdrawMutation.mutate(values);
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-secondary";
      case "pending":
        return "text-yellow-500";
      case "failed":
        return "text-destructive";
      default:
        return "text-muted-foreground";
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-secondary/20 text-secondary";
      case "pending":
        return "bg-yellow-500/20 text-yellow-500";
      case "failed":
      case "rejected":
        return "bg-destructive/20 text-destructive";
      case "approved":
        return "bg-secondary/20 text-secondary";
      default:
        return "bg-muted text-muted-foreground";
    }
  };
  
  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <ArrowDownCircle className="h-5 w-5 text-secondary" />;
      case "withdrawal":
        return <ArrowUpCircle className="h-5 w-5 text-yellow-500" />;
      case "win":
        return <CreditCard className="h-5 w-5 text-secondary" />;
      case "loss":
        return <CreditCard className="h-5 w-5 text-destructive" />;
      case "referral":
        return <RotateCw className="h-5 w-5 text-accent" />;
      default:
        return <Wallet className="h-5 w-5" />;
    }
  };
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar isMobileOpen={isMobileOpen} toggleSidebar={toggleSidebar} />
      
      <main className="flex-1 md:ml-64">
        <TopNav toggleSidebar={toggleSidebar} />
        
        <div className="p-4 md:p-6">
          {/* Balance Card */}
          <section className="mb-8">
            <Card className="bg-gradient-to-r from-primary to-purple-600">
              <CardContent className="p-8">
                <div className="flex flex-col items-center md:items-start">
                  <h2 className="text-xl font-medium text-white/80 mb-2">Current Balance</h2>
                  <p className="text-4xl font-bold text-white">₹{parseFloat(user?.balance?.toString() || "0").toLocaleString('en-IN')}</p>
                  
                  <div className="mt-6 flex gap-3">
                    <Button 
                      variant="secondary" 
                      className="font-medium"
                      onClick={() => window.location.href = '/checkout/upi'}
                    >
                      <ArrowDownCircle className="mr-2 h-4 w-4" />
                      Deposit
                    </Button>
                    <Button 
                      variant="outline" 
                      className="bg-white/10 text-white hover:bg-white/20 font-medium"
                      onClick={() => document.getElementById('withdraw-section')?.scrollIntoView({ behavior: 'smooth' })}
                    >
                      <ArrowUpCircle className="mr-2 h-4 w-4" />
                      Withdraw
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>
          
          {/* Main Tabs */}
          <Tabs defaultValue="transactions" className="space-y-4">
            <TabsList className="w-full max-w-md grid grid-cols-3">
              <TabsTrigger value="transactions">Transactions</TabsTrigger>
              <TabsTrigger value="deposits">Deposits</TabsTrigger>
              <TabsTrigger value="withdrawals">Withdrawals</TabsTrigger>
            </TabsList>
            
            {/* Transactions Tab */}
            <TabsContent value="transactions">
              <Card>
                <CardHeader>
                  <CardTitle>Transaction History</CardTitle>
                  <CardDescription>View your recent deposits, withdrawals, wins and losses.</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingTransactions ? (
                    <div className="flex justify-center py-8">
                      <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : transactions && transactions.length > 0 ? (
                    <div className="space-y-4">
                      {transactions.map((transaction) => (
                        <div key={transaction.id} className="flex items-start border-b border-border pb-4 last:border-0 last:pb-0">
                          <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center mr-3">
                            {getTransactionIcon(transaction.type)}
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between">
                              <div>
                                <p className="font-medium capitalize">{transaction.type}</p>
                                <p className="text-sm text-muted-foreground">
                                  {formatDistanceToNow(new Date(transaction.createdAt), { addSuffix: true })}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className={`font-medium ${
                                  transaction.type === "win" || transaction.type === "deposit" || transaction.type === "referral" 
                                    ? "text-secondary" 
                                    : transaction.type === "loss" ? "text-destructive" : ""
                                }`}>
                                  {transaction.type === "win" || transaction.type === "deposit" || transaction.type === "referral"
                                    ? `+₹${parseFloat(transaction.amount.toString()).toLocaleString('en-IN')}`
                                    : `-₹${parseFloat(transaction.amount.toString()).toLocaleString('en-IN')}`
                                  }
                                </p>
                                <p className={`text-sm ${getStatusColor(transaction.status)}`}>
                                  {transaction.status}
                                </p>
                              </div>
                            </div>
                            {transaction.notes && (
                              <p className="text-sm text-muted-foreground mt-1">{transaction.notes}</p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-10 text-muted-foreground">
                      <p>No transaction history found.</p>
                      <p className="text-sm mt-1">Start playing games or make a deposit to see transactions here.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Deposits Tab */}
            <TabsContent value="deposits">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Deposit History</CardTitle>
                    <CardDescription>Track the status of your deposit requests.</CardDescription>
                  </div>
                  <Button 
                    variant="default"
                    size="sm"
                    onClick={() => window.location.href = '/checkout/upi'}
                  >
                    <ArrowDownCircle className="mr-2 h-4 w-4" />
                    New Deposit
                  </Button>
                </CardHeader>
                <CardContent>
                  {isLoadingDeposits ? (
                    <div className="flex justify-center py-8">
                      <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : deposits && deposits.length > 0 ? (
                    <div className="space-y-4">
                      {deposits.map((deposit) => (
                        <div key={deposit.id} className="border-b border-border pb-4 last:border-0 last:pb-0">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="font-medium">₹{parseFloat(deposit.amount.toString()).toLocaleString('en-IN')}</p>
                                <Badge variant="outline" className="text-xs capitalize">
                                  {deposit.method}
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground">
                                {formatDistanceToNow(new Date(deposit.createdAt), { addSuffix: true })}
                              </p>
                            </div>
                            <div className={`px-2 py-1 rounded-md text-xs font-medium ${getStatusBadge(deposit.status)}`}>
                              {deposit.status}
                            </div>
                          </div>
                          {deposit.method === "upi" && deposit.utrNumber && (
                            <div className="text-sm mt-1">
                              <span className="text-muted-foreground">UTR:</span> {deposit.utrNumber}
                            </div>
                          )}
                          {deposit.method === "usdt" && deposit.walletAddress && (
                            <div className="text-sm mt-1">
                              <span className="text-muted-foreground">Transaction:</span> {deposit.walletAddress}
                            </div>
                          )}
                          {deposit.notes && (
                            <div className="text-sm mt-1 text-muted-foreground">{deposit.notes}</div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-10 text-muted-foreground">
                      <p>No deposit history found.</p>
                      <p className="text-sm mt-1">Make a deposit to see your history here.</p>
                      <Button 
                        variant="outline"
                        size="sm"
                        className="mt-4"
                        onClick={() => window.location.href = '/checkout/upi'}
                      >
                        <ArrowDownCircle className="mr-2 h-4 w-4" />
                        Make a Deposit
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Withdrawals Tab */}
            <TabsContent value="withdrawals">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Withdrawal Form */}
                <Card id="withdraw-section">
                  <CardHeader>
                    <CardTitle>Request Withdrawal</CardTitle>
                    <CardDescription>
                      Enter the amount you want to withdraw from your wallet.
                      {settings && (
                        <p className="mt-1">
                          Limit: ₹{parseFloat(settings.minWithdrawalAmount?.toString() || "0").toLocaleString('en-IN')} - 
                          ₹{parseFloat(settings.maxWithdrawalAmount?.toString() || "0").toLocaleString('en-IN')}
                        </p>
                      )}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                          control={form.control}
                          name="amount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Amount (₹)</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" placeholder="Enter amount" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="utrNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>UPI ID / Bank Account</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="Enter your payment details" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button 
                          type="submit" 
                          className="w-full"
                          disabled={withdrawMutation.isPending}
                        >
                          {withdrawMutation.isPending ? "Processing..." : "Request Withdrawal"}
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
                
                {/* Withdrawal History */}
                <Card>
                  <CardHeader>
                    <CardTitle>Withdrawal History</CardTitle>
                    <CardDescription>Track the status of your withdrawal requests.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingWithdrawals ? (
                      <div className="flex justify-center py-8">
                        <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                      </div>
                    ) : withdrawals && withdrawals.length > 0 ? (
                      <div className="space-y-4">
                        {withdrawals.map((withdrawal) => (
                          <div key={withdrawal.id} className="border-b border-border pb-4 last:border-0 last:pb-0">
                            <div className="flex justify-between items-start mb-2">
                              <div>
                                <p className="font-medium">₹{parseFloat(withdrawal.amount.toString()).toLocaleString('en-IN')}</p>
                                <p className="text-sm text-muted-foreground">
                                  {formatDistanceToNow(new Date(withdrawal.createdAt), { addSuffix: true })}
                                </p>
                              </div>
                              <div className={`px-2 py-1 rounded-md text-xs font-medium ${getStatusBadge(withdrawal.status)}`}>
                                {withdrawal.status}
                              </div>
                            </div>
                            {withdrawal.utrNumber && (
                              <div className="text-sm mt-1">
                                <span className="text-muted-foreground">UTR:</span> {withdrawal.utrNumber}
                              </div>
                            )}
                            {withdrawal.notes && (
                              <div className="text-sm mt-1 text-muted-foreground">{withdrawal.notes}</div>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-10 text-muted-foreground">
                        <p>No withdrawal history found.</p>
                        <p className="text-sm mt-1">Your withdrawal requests will appear here.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Deposit Modal */}
      <Dialog open={isDepositModalOpen} onOpenChange={setIsDepositModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Funds to Your Wallet</DialogTitle>
            <DialogDescription>
              Select a payment method and enter the amount to deposit.
            </DialogDescription>
          </DialogHeader>

          <Form {...depositForm}>
            <form onSubmit={depositForm.handleSubmit(onDepositSubmit)} className="space-y-4">
              <FormField
                control={depositForm.control}
                name="method"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Method</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a payment method" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="upi">
                          <div className="flex items-center">
                            <IndianRupee className="mr-2 h-4 w-4" />
                            <span>UPI</span>
                          </div>
                        </SelectItem>
                        <SelectItem value="usdt">
                          <div className="flex items-center">
                            <Coins className="mr-2 h-4 w-4" />
                            <span>USDT (Tether)</span>
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={depositForm.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount</FormLabel>
                    <FormControl>
                      <Input 
                        {...field}
                        type="number" 
                        placeholder={
                          depositForm.watch("method") === "upi" 
                            ? `₹${parseFloat(settings?.minUpiDeposit?.toString() || "500")} - ₹${parseFloat(settings?.maxUpiDeposit?.toString() || "30000")}`
                            : `$${parseFloat(settings?.minUsdtDeposit?.toString() || "10")} minimum`
                        }
                      />
                    </FormControl>
                    <FormDescription>
                      {depositForm.watch("method") === "upi" && settings?.minUpiDeposit && settings?.maxUpiDeposit && (
                        <span>Min: ₹{parseFloat(settings.minUpiDeposit.toString()).toLocaleString('en-IN')} - 
                        Max: ₹{parseFloat(settings.maxUpiDeposit.toString()).toLocaleString('en-IN')}</span>
                      )}
                      {depositForm.watch("method") === "usdt" && settings?.minUsdtDeposit && (
                        <span>Min: ${parseFloat(settings.minUsdtDeposit.toString()).toLocaleString('en-US')}</span>
                      )}
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {depositForm.watch("method") === "upi" && (
                <FormField
                  control={depositForm.control}
                  name="utrNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>UTR Number</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Enter UTR number" />
                      </FormControl>
                      <FormDescription>
                        <Button 
                          type="button" 
                          variant="link" 
                          className="p-0 h-auto text-xs"
                          onClick={() => {
                            setDepositMethod("upi");
                            setDepositAmount(depositForm.getValues().amount);
                            setIsQrModalOpen(true);
                          }}
                        >
                          <QrCode className="h-3 w-3 mr-1" />
                          View UPI QR Code
                        </Button>
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {depositForm.watch("method") === "usdt" && (
                <FormField
                  control={depositForm.control}
                  name="walletAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Transaction Hash</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Enter transaction hash" />
                      </FormControl>
                      <FormDescription>
                        <Button 
                          type="button" 
                          variant="link" 
                          className="p-0 h-auto text-xs"
                          onClick={() => {
                            setDepositMethod("usdt");
                            setDepositAmount(depositForm.getValues().amount);
                            setIsQrModalOpen(true);
                          }}
                        >
                          <QrCode className="h-3 w-3 mr-1" />
                          View USDT Wallet Address
                        </Button>
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              <Button 
                type="submit" 
                className="w-full mt-4"
                disabled={depositMutation.isPending}
              >
                {depositMutation.isPending ? "Processing..." : "Submit Deposit Request"}
              </Button>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* QR Code Payment Modal */}
      <Dialog open={isQrModalOpen} onOpenChange={setIsQrModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {depositMethod === "upi" ? "UPI Payment" : "USDT Payment"}
            </DialogTitle>
            <DialogDescription>
              {depositMethod === "upi" 
                ? `Please scan the QR code below and complete the payment of ₹${parseFloat(depositAmount).toLocaleString('en-IN')}`
                : `Please send USDT worth ₹${parseFloat(depositAmount).toLocaleString('en-IN')} to the address below`
              }
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex flex-col items-center space-y-4">
            {/* QR Code Image */}
            <div className="border border-border rounded-lg p-2 bg-white">
              {depositMethod === "upi" && settings?.upiQrUrl ? (
                <img 
                  src={settings.upiQrUrl} 
                  alt="UPI QR Code" 
                  className="w-64 h-64 object-contain"
                />
              ) : depositMethod === "usdt" && settings?.usdtQrUrl ? (
                <img 
                  src={settings.usdtQrUrl} 
                  alt="USDT QR Code" 
                  className="w-64 h-64 object-contain"
                />
              ) : (
                <div className="w-64 h-64 flex items-center justify-center bg-muted">
                  <QrCode className="w-16 h-16 text-muted-foreground" />
                </div>
              )}
            </div>
            
            {/* Payment Details */}
            <div className="w-full space-y-2">
              {depositMethod === "upi" && settings?.upiId && (
                <div className="flex flex-col space-y-1">
                  <Label>UPI ID</Label>
                  <div className="flex items-center border rounded-md p-2 bg-muted">
                    <span className="flex-1 font-mono text-sm">{settings.upiId}</span>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="h-8 px-2 ml-2"
                      onClick={() => {
                        if (settings?.upiId) {
                          navigator.clipboard.writeText(settings.upiId);
                          toast({
                            description: "UPI ID copied to clipboard",
                          });
                        }
                      }}
                    >
                      Copy
                    </Button>
                  </div>
                </div>
              )}
              
              {depositMethod === "usdt" && settings?.usdtAddress && (
                <div className="flex flex-col space-y-1">
                  <Label>USDT Address</Label>
                  <div className="flex items-center border rounded-md p-2 bg-muted">
                    <span className="flex-1 font-mono text-sm overflow-x-auto">{settings.usdtAddress}</span>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="h-8 px-2 ml-2"
                      onClick={() => {
                        if (settings?.usdtAddress) {
                          navigator.clipboard.writeText(settings.usdtAddress);
                          toast({
                            description: "Address copied to clipboard",
                          });
                        }
                      }}
                    >
                      Copy
                    </Button>
                  </div>
                </div>
              )}
              
              {/* UTR Number Input Form */}
              {depositMethod === "upi" && (
                <form onSubmit={(e) => {
                  e.preventDefault();
                  const form = e.currentTarget;
                  const formData = new FormData(form);
                  const utrNumber = formData.get('utrNumber') as string;
                  
                  if (!utrNumber) {
                    toast({
                      title: "UTR number required",
                      description: "Please enter the UTR number after completing the payment",
                      variant: "destructive",
                    });
                    return;
                  }
                  
                  if (utrNumber.length > 12) {
                    toast({
                      title: "Invalid UTR number",
                      description: "UTR number cannot exceed 12 digits",
                      variant: "destructive",
                    });
                    return;
                  }
                  
                  handlePaymentComplete(utrNumber);
                }}>
                  <div className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label htmlFor="utrNumber">Enter UTR Number</Label>
                      <Input 
                        id="utrNumber" 
                        name="utrNumber" 
                        placeholder="Enter 12 digit UTR number" 
                        maxLength={12}
                        required
                      />
                      <p className="text-xs text-muted-foreground">
                        You'll find the UTR number in your UPI app payment history
                      </p>
                    </div>
                    
                    <Button type="submit" className="w-full">
                      Submit Payment Details
                    </Button>
                  </div>
                </form>
              )}
              
              {/* For USDT, transaction hash entry is in the main form */}
              {depositMethod === "usdt" && (
                <Button 
                  className="w-full mt-4" 
                  onClick={() => setIsQrModalOpen(false)}
                >
                  I'll Enter Transaction Hash
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
