import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import TopNav from "@/components/top-nav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { SystemSettings, Transaction } from "@shared/schema";
import { RotateCw, Save, Users, Award, Settings, ArrowRight, TrendingUp, Share2 } from "lucide-react";
import { format } from "date-fns";

const referralSettingsSchema = z.object({
  minWithdrawalAmount: z.coerce.number().min(1, "Minimum withdrawal amount must be at least 1"),
  maxWithdrawalAmount: z.coerce.number().min(1, "Maximum withdrawal amount must be at least 1"),
  referralBonus: z.coerce.number().min(1, "Referral bonus must be at least 1"),
});

type ReferralSettingsFormValues = z.infer<typeof referralSettingsSchema>;

export default function ReferralSettings() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { toast } = useToast();
  
  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };
  
  // Fetch system settings
  const { data: settings, isLoading: isLoadingSettings } = useQuery<SystemSettings>({
    queryKey: ["/api/settings"],
  });
  
  // Fetch all referral transactions
  const { data: transactions, isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/admin/transactions"],
    select: (data) => data.filter(tx => tx.type === "referral").slice(0, 20)
  });
  
  // Setup form for settings
  const form = useForm<ReferralSettingsFormValues>({
    resolver: zodResolver(referralSettingsSchema),
    defaultValues: {
      minWithdrawalAmount: 100,
      maxWithdrawalAmount: 10000,
      referralBonus: 100,
    },
  });
  
  // Reset form when settings change
  React.useEffect(() => {
    if (settings) {
      form.reset({
        minWithdrawalAmount: parseFloat(settings.minWithdrawalAmount.toString()),
        maxWithdrawalAmount: parseFloat(settings.maxWithdrawalAmount.toString()),
        referralBonus: parseFloat(settings.referralBonus.toString()),
      });
    }
  }, [settings, form]);
  
  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (values: ReferralSettingsFormValues) => {
      const response = await apiRequest("PUT", "/api/admin/settings", values);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Settings updated",
        description: "Referral and withdrawal settings have been updated",
      });
      
      // Refresh settings data
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: ReferralSettingsFormValues) => {
    // Check if max is greater than min
    if (values.maxWithdrawalAmount < values.minWithdrawalAmount) {
      toast({
        title: "Invalid settings",
        description: "Maximum withdrawal amount must be greater than minimum",
        variant: "destructive",
      });
      return;
    }
    
    updateSettingsMutation.mutate(values);
  };
  
  // Calculate stats
  const totalReferralCount = transactions?.length || 0;
  const totalReferralAmount = transactions?.reduce((sum, tx) => 
    sum + parseFloat(tx.amount.toString()), 0) || 0;
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar isMobileOpen={isMobileOpen} setIsMobileOpen={setIsMobileOpen} />
      
      <main className="flex-1 md:ml-64">
        <TopNav toggleSidebar={toggleSidebar} />
        
        <div className="p-4 md:p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Referral & Withdrawal Settings</h1>
            <p className="text-muted-foreground">Configure referral bonuses and withdrawal limits.</p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Settings Card */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>System Settings</CardTitle>
                  <CardDescription>Configure platform-wide settings for referrals and withdrawals</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingSettings ? (
                    <div className="flex justify-center py-8">
                      <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : (
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-4">
                            <div className="flex items-center mb-4">
                              <Award className="h-5 w-5 mr-2 text-primary" />
                              <h3 className="text-lg font-semibold">Referral Settings</h3>
                            </div>
                            
                            <FormField
                              control={form.control}
                              name="referralBonus"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Referral Bonus Amount (₹)</FormLabel>
                                  <FormControl>
                                    <Input type="number" {...field} min="1" />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <div className="text-sm text-muted-foreground">
                              <p>This is the amount a user receives when someone signs up using their referral code.</p>
                            </div>
                          </div>
                          
                          <div className="space-y-4">
                            <div className="flex items-center mb-4">
                              <Settings className="h-5 w-5 mr-2 text-primary" />
                              <h3 className="text-lg font-semibold">Withdrawal Limits</h3>
                            </div>
                            
                            <FormField
                              control={form.control}
                              name="minWithdrawalAmount"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Minimum Withdrawal Amount (₹)</FormLabel>
                                  <FormControl>
                                    <Input type="number" {...field} min="1" />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="maxWithdrawalAmount"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Maximum Withdrawal Amount (₹)</FormLabel>
                                  <FormControl>
                                    <Input type="number" {...field} min="1" />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                        
                        <Button 
                          type="submit" 
                          className="w-full md:w-auto"
                          disabled={updateSettingsMutation.isPending}
                        >
                          {updateSettingsMutation.isPending ? (
                            <>
                              <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                              Saving...
                            </>
                          ) : (
                            <>
                              <Save className="mr-2 h-4 w-4" />
                              Save Settings
                            </>
                          )}
                        </Button>
                      </form>
                    </Form>
                  )}
                </CardContent>
              </Card>
            </div>
            
            {/* Stats Card */}
            <Card>
              <CardHeader>
                <CardTitle>Referral Statistics</CardTitle>
                <CardDescription>Overview of platform referral activity</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-primary/10 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-primary mb-1">Total Referrals</h3>
                  <div className="flex items-center">
                    <Users className="h-5 w-5 mr-2 text-primary" />
                    <p className="text-2xl font-bold">{totalReferralCount}</p>
                  </div>
                </div>
                
                <div className="bg-secondary/10 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-secondary mb-1">Total Bonus Amount</h3>
                  <div className="flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2 text-secondary" />
                    <p className="text-2xl font-bold">₹{totalReferralAmount.toLocaleString('en-IN')}</p>
                  </div>
                </div>
                
                <div className="bg-accent/10 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-accent mb-1">Current Bonus Rate</h3>
                  <div className="flex items-center">
                    <Award className="h-5 w-5 mr-2 text-accent" />
                    <p className="text-2xl font-bold">₹{settings ? parseFloat(settings.referralBonus.toString()) : '...'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Recent Referrals */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Referrals</CardTitle>
              <CardDescription>Recent referral bonuses paid out to users</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingTransactions ? (
                <div className="flex justify-center py-8">
                  <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : transactions && transactions.length > 0 ? (
                <div className="rounded-md border">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 font-medium">User</th>
                          <th className="text-left py-3 px-4 font-medium">Amount</th>
                          <th className="text-left py-3 px-4 font-medium">Date</th>
                          <th className="text-left py-3 px-4 font-medium">Status</th>
                          <th className="text-left py-3 px-4 font-medium">Notes</th>
                        </tr>
                      </thead>
                      <tbody>
                        {transactions.map((transaction) => (
                          <tr key={transaction.id} className="border-b border-border hover:bg-muted/30">
                            <td className="py-3 px-4">User #{transaction.userId}</td>
                            <td className="py-3 px-4 font-medium text-secondary">+₹{parseFloat(transaction.amount.toString()).toLocaleString('en-IN')}</td>
                            <td className="py-3 px-4 text-muted-foreground">
                              {format(new Date(transaction.createdAt), "MMM d, yyyy h:mm a")}
                            </td>
                            <td className="py-3 px-4">
                              <Badge className="bg-secondary text-secondary-foreground">
                                {transaction.status}
                              </Badge>
                            </td>
                            <td className="py-3 px-4 text-muted-foreground">
                              {transaction.notes}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className="text-center py-10 text-muted-foreground">
                  <Share2 className="h-12 w-12 mx-auto mb-4 opacity-30" />
                  <p>No referral transactions found.</p>
                  <p className="text-sm mt-1">Referrals will appear here when users sign up with referral codes.</p>
                </div>
              )}
            </CardContent>
            {transactions && transactions.length > 0 && (
              <CardFooter className="flex justify-between">
                <div className="text-sm text-muted-foreground">
                  Showing latest {transactions.length} referrals
                </div>
                <Button variant="outline" size="sm">
                  View All <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            )}
          </Card>
        </div>
      </main>
    </div>
  );
}
