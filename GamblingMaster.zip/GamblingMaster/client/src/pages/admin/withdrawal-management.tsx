import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import TopNav from "@/components/top-nav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { WithdrawalRequest } from "@shared/schema";
import { Search, Filter, Check, X, RotateCw, MoreHorizontal, FileText, ArrowUpDown, CheckCircle2, Clock, XCircle } from "lucide-react";
import { format } from "date-fns";

const processWithdrawalSchema = z.object({
  status: z.enum(["approved", "rejected"]),
  utrNumber: z.string().optional().nullable(),
  notes: z.string().optional(),
});

type ProcessWithdrawalValues = z.infer<typeof processWithdrawalSchema>;

export default function WithdrawalManagement() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<WithdrawalRequest | null>(null);
  const [isProcessDialogOpen, setIsProcessDialogOpen] = useState(false);
  const { toast } = useToast();
  
  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };
  
  // Fetch all withdrawals
  const { data: withdrawals, isLoading: isLoadingWithdrawals } = useQuery<WithdrawalRequest[]>({
    queryKey: ["/api/admin/withdrawals"],
  });
  
  // Filter withdrawals based on search term and status
  const filteredWithdrawals = withdrawals?.filter(withdrawal => {
    if (statusFilter !== "all" && withdrawal.status !== statusFilter) {
      return false;
    }
    
    if (!searchTerm) return true;
    
    const searchLower = searchTerm.toLowerCase();
    return (
      withdrawal.id.toString().includes(searchLower) ||
      withdrawal.userId.toString().includes(searchLower) ||
      (withdrawal.utrNumber && withdrawal.utrNumber.toLowerCase().includes(searchLower)) ||
      (withdrawal.notes && withdrawal.notes.toLowerCase().includes(searchLower))
    );
  });
  
  // Setup form for processing withdrawals
  const form = useForm<ProcessWithdrawalValues>({
    resolver: zodResolver(processWithdrawalSchema),
    defaultValues: {
      status: "approved",
      utrNumber: "",
      notes: "",
    },
  });
  
  // Reset form when selected withdrawal changes
  React.useEffect(() => {
    if (selectedWithdrawal) {
      form.reset({
        status: "approved",
        utrNumber: "",
        notes: "",
      });
    }
  }, [selectedWithdrawal, form]);
  
  // Process withdrawal mutation
  const processWithdrawalMutation = useMutation({
    mutationFn: async (values: ProcessWithdrawalValues) => {
      if (!selectedWithdrawal) throw new Error("No withdrawal selected");
      
      const response = await apiRequest("PUT", `/api/admin/withdrawals/${selectedWithdrawal.id}`, values);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: `Withdrawal ${form.getValues().status}`,
        description: `Withdrawal #${selectedWithdrawal?.id} has been ${form.getValues().status}`,
      });
      
      // Refresh withdrawals data
      queryClient.invalidateQueries({ queryKey: ["/api/admin/withdrawals"] });
      setIsProcessDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Process failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleProcessWithdrawal = (withdrawal: WithdrawalRequest) => {
    setSelectedWithdrawal(withdrawal);
    setIsProcessDialogOpen(true);
  };
  
  const onSubmit = (values: ProcessWithdrawalValues) => {
    processWithdrawalMutation.mutate(values);
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-secondary text-secondary-foreground flex items-center gap-1">
          <CheckCircle2 className="h-3 w-3" /> Approved
        </Badge>;
      case "pending":
        return <Badge className="bg-yellow-500 text-white flex items-center gap-1">
          <Clock className="h-3 w-3" /> Pending
        </Badge>;
      case "rejected":
        return <Badge className="bg-destructive text-destructive-foreground flex items-center gap-1">
          <XCircle className="h-3 w-3" /> Rejected
        </Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  // Calculate total pending amount
  const pendingAmount = filteredWithdrawals
    ?.filter(w => w.status === "pending")
    .reduce((sum, w) => sum + parseFloat(w.amount.toString()), 0) || 0;
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar isMobileOpen={isMobileOpen} setIsMobileOpen={setIsMobileOpen} />
      
      <main className="flex-1 md:ml-64">
        <TopNav toggleSidebar={toggleSidebar} />
        
        <div className="p-4 md:p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Withdrawal Management</h1>
            <p className="text-muted-foreground">Manage and process user withdrawal requests.</p>
          </div>
          
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-muted rounded-lg p-4">
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Total Requests</h3>
                  <p className="text-2xl font-bold">{withdrawals?.length || 0}</p>
                </div>
                
                <div className="bg-yellow-500/10 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-yellow-500 mb-1">Pending Requests</h3>
                  <p className="text-2xl font-bold text-yellow-500">
                    {withdrawals?.filter(w => w.status === "pending").length || 0}
                  </p>
                </div>
                
                <div className="bg-yellow-500/10 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-yellow-500 mb-1">Pending Amount</h3>
                  <p className="text-2xl font-bold text-yellow-500">
                    ₹{pendingAmount.toLocaleString('en-IN')}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle>Withdrawal Requests</CardTitle>
                  <CardDescription>Manage user withdrawal requests</CardDescription>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search..."
                      className="pl-9 w-full"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoadingWithdrawals ? (
                <div className="flex justify-center py-8">
                  <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : filteredWithdrawals && filteredWithdrawals.length > 0 ? (
                <div className="rounded-md border">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 font-medium">ID</th>
                          <th className="text-left py-3 px-4 font-medium">User</th>
                          <th className="text-left py-3 px-4 font-medium">Amount</th>
                          <th className="text-left py-3 px-4 font-medium">Request Date</th>
                          <th className="text-left py-3 px-4 font-medium">Status</th>
                          <th className="text-left py-3 px-4 font-medium">UTR/Details</th>
                          <th className="text-left py-3 px-4 font-medium">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredWithdrawals.map((withdrawal) => (
                          <tr key={withdrawal.id} className="border-b border-border hover:bg-muted/30">
                            <td className="py-3 px-4 font-mono text-xs">{withdrawal.id}</td>
                            <td className="py-3 px-4">User #{withdrawal.userId}</td>
                            <td className="py-3 px-4 font-medium">₹{parseFloat(withdrawal.amount.toString()).toLocaleString('en-IN')}</td>
                            <td className="py-3 px-4 text-muted-foreground">
                              {format(new Date(withdrawal.createdAt), "MMM d, yyyy h:mm a")}
                            </td>
                            <td className="py-3 px-4">
                              {getStatusBadge(withdrawal.status)}
                            </td>
                            <td className="py-3 px-4">
                              {withdrawal.utrNumber ? (
                                <div className="flex items-center">
                                  <FileText className="h-4 w-4 mr-2 text-muted-foreground" />
                                  <span className="font-mono text-xs">{withdrawal.utrNumber}</span>
                                </div>
                              ) : (
                                <span className="text-muted-foreground text-sm">No UTR</span>
                              )}
                              {withdrawal.notes && (
                                <div className="text-xs text-muted-foreground mt-1 truncate max-w-xs">
                                  {withdrawal.notes}
                                </div>
                              )}
                            </td>
                            <td className="py-3 px-4">
                              {withdrawal.status === "pending" ? (
                                <div className="flex space-x-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="h-8 px-2 text-xs"
                                    onClick={() => handleProcessWithdrawal(withdrawal)}
                                  >
                                    <MoreHorizontal className="h-4 w-4 mr-1" /> Process
                                  </Button>
                                </div>
                              ) : (
                                <span className="text-xs text-muted-foreground">
                                  {format(new Date(withdrawal.updatedAt), "MMM d, yyyy")}
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className="text-center py-10 text-muted-foreground">
                  <ArrowUpDown className="h-12 w-12 mx-auto mb-4 opacity-30" />
                  <p>No withdrawal requests found.</p>
                  {searchTerm || statusFilter !== "all" ? (
                    <p className="text-sm mt-1">Try adjusting your filters.</p>
                  ) : null}
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Process Withdrawal Dialog */}
          <Dialog open={isProcessDialogOpen} onOpenChange={setIsProcessDialogOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Process Withdrawal</DialogTitle>
                <DialogDescription>
                  {selectedWithdrawal && (
                    <div className="mt-2">
                      <p>User: #{selectedWithdrawal.userId}</p>
                      <p>Amount: ₹{parseFloat(selectedWithdrawal.amount.toString()).toLocaleString('en-IN')}</p>
                      <p>Request Date: {format(new Date(selectedWithdrawal.createdAt), "MMM d, yyyy h:mm a")}</p>
                    </div>
                  )}
                </DialogDescription>
              </DialogHeader>
              
              {selectedWithdrawal && (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Status</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select status" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="approved" className="flex items-center">
                                <Check className="h-4 w-4 mr-2 text-secondary" /> Approve
                              </SelectItem>
                              <SelectItem value="rejected">
                                <X className="h-4 w-4 mr-2 text-destructive" /> Reject
                              </SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {form.watch("status") === "approved" && (
                      <FormField
                        control={form.control}
                        name="utrNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>UTR Number</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter UTR number" {...field} value={field.value || ""} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                    
                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Notes (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="Add notes about this transaction" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <DialogFooter>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setIsProcessDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        disabled={processWithdrawalMutation.isPending}
                        variant={form.watch("status") === "approved" ? "default" : "destructive"}
                      >
                        {processWithdrawalMutation.isPending
                          ? "Processing..."
                          : form.watch("status") === "approved"
                          ? "Approve Withdrawal"
                          : "Reject Withdrawal"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              )}
            </DialogContent>
          </Dialog>
        </div>
      </main>
    </div>
  );
}
