import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import TopNav from "@/components/top-nav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { GameHistory, SystemSettings } from "@shared/schema";
import { RotateCw, Search, Filter, ArrowUpDown, CalendarIcon, Coins, Dice5, RotateCcw, CreditCard, Hash, Users, Percent, Zap, Settings2 } from "lucide-react";
import { format } from "date-fns";

// Schema for game win chance settings
const gameWinChanceSchema = z.object({
  coinTossWinChance: z.number().min(0).max(100),
  diceRollWinChance: z.number().min(0).max(100),
  cardFlipWinChance: z.number().min(0).max(100),
  wheelFortuneWinChance: z.number().min(0).max(100),
  luckyNumberWinChance: z.number().min(0).max(100),
});

type GameWinChanceFormValues = z.infer<typeof gameWinChanceSchema>;

export default function GameControls() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [gameFilter, setGameFilter] = useState<string>("all");
  const [outcomeFilter, setOutcomeFilter] = useState<string>("all");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const { toast } = useToast();
  
  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };
  
  // Fetch all game history
  const { data: gameHistory, isLoading: isLoadingHistory } = useQuery<GameHistory[]>({
    queryKey: ["/api/admin/games/history"],
  });
  
  // Setup form for game win chance settings
  const form = useForm<GameWinChanceFormValues>({
    resolver: zodResolver(gameWinChanceSchema),
    defaultValues: {
      coinTossWinChance: 50,
      diceRollWinChance: 50,
      cardFlipWinChance: 50,
      wheelFortuneWinChance: 50,
      luckyNumberWinChance: 50,
    },
  });
  
  // Fetch system settings for game win chances
  const { data: settings, isLoading: isLoadingSettings } = useQuery<SystemSettings>({
    queryKey: ["/api/settings"],
  });
  
  // Update form when settings are loaded
  useEffect(() => {
    if (settings) {
      form.reset({
        coinTossWinChance: settings.coinTossWinChance || 50,
        diceRollWinChance: settings.diceRollWinChance || 50,
        cardFlipWinChance: settings.cardFlipWinChance || 50,
        wheelFortuneWinChance: settings.wheelFortuneWinChance || 50,
        luckyNumberWinChance: settings.luckyNumberWinChance || 50,
      });
    }
  }, [settings, form]);
  
  // Update win chance settings mutation
  const updateWinChanceMutation = useMutation({
    mutationFn: async (data: GameWinChanceFormValues) => {
      // Preserve other settings
      const fullData = {
        ...data,
        // Include existing settings that we don't want to change
        minWithdrawalAmount: parseFloat(settings?.minWithdrawalAmount?.toString() || "100"),
        maxWithdrawalAmount: parseFloat(settings?.maxWithdrawalAmount?.toString() || "10000"),
        referralBonus: parseFloat(settings?.referralBonus?.toString() || "100"),
      };
      
      const res = await apiRequest("PUT", "/api/admin/settings", fullData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Game settings updated",
        description: "Win chance settings have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update game settings",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (values: GameWinChanceFormValues) => {
    updateWinChanceMutation.mutate(values);
  };
  
  // Filter and sort game history
  const filteredGames = gameHistory?.filter(game => {
    // Apply game type filter
    if (gameFilter !== "all" && game.gameType !== gameFilter) {
      return false;
    }
    
    // Apply outcome filter
    if (outcomeFilter !== "all" && game.outcome !== outcomeFilter) {
      return false;
    }
    
    // Apply search filter (search in userId, gameType, or outcome)
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      return (
        game.userId.toString().includes(searchLower) ||
        game.gameType.toLowerCase().includes(searchLower) ||
        game.outcome.toLowerCase().includes(searchLower)
      );
    }
    
    return true;
  });
  
  // Sort games by timestamp
  const sortedGames = filteredGames?.sort((a, b) => {
    const dateA = new Date(a.createdAt).getTime();
    const dateB = new Date(b.createdAt).getTime();
    return sortOrder === "asc" ? dateA - dateB : dateB - dateA;
  });
  
  // Calculate stats
  const totalGames = gameHistory?.length || 0;
  const winCount = gameHistory?.filter(game => game.outcome === "win").length || 0;
  const lossCount = gameHistory?.filter(game => game.outcome === "loss").length || 0;
  const totalBetAmount = gameHistory?.reduce((total, game) => total + parseFloat(game.betAmount.toString()), 0) || 0;
  const totalWinAmount = gameHistory?.filter(game => game.outcome === "win")
    .reduce((total, game) => total + parseFloat(game.winAmount.toString()), 0) || 0;
  const platformProfit = totalBetAmount - totalWinAmount;
  
  // Game counts by type
  const gameCounts = gameHistory?.reduce((acc, game) => {
    acc[game.gameType] = (acc[game.gameType] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};
  
  // Game icons
  const getGameIcon = (gameType: string) => {
    switch (gameType) {
      case "coinToss": return <Coins className="h-5 w-5" />;
      case "diceRoll": return <Dice5 className="h-5 w-5" />;
      case "wheelFortune": return <RotateCcw className="h-5 w-5" />;
      case "cardFlip": return <CreditCard className="h-5 w-5" />;
      case "luckyNumber": return <Hash className="h-5 w-5" />;
      default: return <Coins className="h-5 w-5" />;
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar isMobileOpen={isMobileOpen} toggleSidebar={toggleSidebar} />
      
      <div className="flex-1">
        <TopNav toggleSidebar={toggleSidebar} />
        
        <main className="p-4 md:p-6 max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-3xl font-bold tracking-tight">Game Controls</h1>
          </div>
          
          <Tabs defaultValue="win-chance" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="win-chance">Win Chance Settings</TabsTrigger>
              <TabsTrigger value="statistics">Statistics</TabsTrigger>
              <TabsTrigger value="game-history">Game History</TabsTrigger>
            </TabsList>
            
            <TabsContent value="win-chance" className="space-y-6">
              {isLoadingSettings ? (
                <div className="flex items-center justify-center h-64">
                  <RotateCw className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                    <Card>
                      <CardHeader>
                        <CardTitle>Game Win Chances</CardTitle>
                        <CardDescription>Configure win probability for each game (0-100%)</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        <FormField
                          control={form.control}
                          name="coinTossWinChance"
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex items-center justify-between mb-2">
                                <FormLabel>Coin Toss Win Chance</FormLabel>
                                <span className="text-sm font-medium">{field.value}%</span>
                              </div>
                              <FormControl>
                                <Slider
                                  min={0}
                                  max={100}
                                  step={1}
                                  defaultValue={[field.value]}
                                  onValueChange={(values) => field.onChange(values[0])}
                                  className="w-full"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="diceRollWinChance"
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex items-center justify-between mb-2">
                                <FormLabel>Dice Roll Win Chance</FormLabel>
                                <span className="text-sm font-medium">{field.value}%</span>
                              </div>
                              <FormControl>
                                <Slider
                                  min={0}
                                  max={100}
                                  step={1}
                                  defaultValue={[field.value]}
                                  onValueChange={(values) => field.onChange(values[0])}
                                  className="w-full"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="cardFlipWinChance"
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex items-center justify-between mb-2">
                                <FormLabel>Card Flip Win Chance</FormLabel>
                                <span className="text-sm font-medium">{field.value}%</span>
                              </div>
                              <FormControl>
                                <Slider
                                  min={0}
                                  max={100}
                                  step={1}
                                  defaultValue={[field.value]}
                                  onValueChange={(values) => field.onChange(values[0])}
                                  className="w-full"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="wheelFortuneWinChance"
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex items-center justify-between mb-2">
                                <FormLabel>Wheel of Fortune Win Chance</FormLabel>
                                <span className="text-sm font-medium">{field.value}%</span>
                              </div>
                              <FormControl>
                                <Slider
                                  min={0}
                                  max={100}
                                  step={1}
                                  defaultValue={[field.value]}
                                  onValueChange={(values) => field.onChange(values[0])}
                                  className="w-full"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="luckyNumberWinChance"
                          render={({ field }) => (
                            <FormItem>
                              <div className="flex items-center justify-between mb-2">
                                <FormLabel>Lucky Number Win Chance</FormLabel>
                                <span className="text-sm font-medium">{field.value}%</span>
                              </div>
                              <FormControl>
                                <Slider
                                  min={0}
                                  max={100}
                                  step={1}
                                  defaultValue={[field.value]}
                                  onValueChange={(values) => field.onChange(values[0])}
                                  className="w-full"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </CardContent>
                      <CardFooter>
                        <Button 
                          type="submit" 
                          className="w-full" 
                          disabled={updateWinChanceMutation.isPending}
                        >
                          {updateWinChanceMutation.isPending && (
                            <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                          )}
                          Save Win Chance Settings
                        </Button>
                      </CardFooter>
                    </Card>
                  </form>
                </Form>
              )}
            </TabsContent>
            
            <TabsContent value="statistics">
              <div className="space-y-6">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">Total Games</p>
                          <h3 className="text-2xl font-bold mt-1">{totalGames}</h3>
                        </div>
                        <div className="h-12 w-12 rounded-lg bg-primary/20 flex items-center justify-center">
                          <Coins className="h-6 w-6 text-primary" />
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground mt-4 flex items-center">
                        <Filter className="h-4 w-4 mr-1" /> Across all game types
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">Win/Loss Ratio</p>
                          <h3 className="text-2xl font-bold mt-1">
                            {winCount}:{lossCount}
                          </h3>
                        </div>
                        <div className="h-12 w-12 rounded-lg bg-muted flex items-center justify-center">
                          <div className="flex space-x-1">
                            <div className="h-5 w-2 bg-secondary rounded"></div>
                            <div className="h-5 w-2 bg-destructive rounded"></div>
                          </div>
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground mt-4 flex items-center">
                        <span className="text-secondary mr-1">{((winCount / totalGames) * 100 || 0).toFixed(1)}%</span> win rate
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">Total Bet Amount</p>
                          <h3 className="text-2xl font-bold mt-1">₹{totalBetAmount.toLocaleString('en-IN')}</h3>
                        </div>
                        <div className="h-12 w-12 rounded-lg bg-accent/20 flex items-center justify-center">
                          <Dice5 className="h-6 w-6 text-accent" />
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground mt-4 flex items-center">
                        <ArrowUpDown className="h-4 w-4 mr-1" /> ₹{(totalBetAmount / totalGames || 0).toFixed(2)} avg. bet
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-muted-foreground">Platform Profit</p>
                          <h3 className="text-2xl font-bold mt-1">₹{platformProfit.toLocaleString('en-IN')}</h3>
                        </div>
                        <div className="h-12 w-12 rounded-lg bg-secondary/20 flex items-center justify-center">
                          <RotateCcw className="h-6 w-6 text-secondary" />
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground mt-4 flex items-center">
                        {platformProfit > 0 ? (
                          <span className="text-secondary">Profitable</span>
                        ) : (
                          <span className="text-destructive">Loss</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Game Distribution */}
                <div className="mb-8">
                  <h2 className="text-lg font-semibold mb-4">Game Distribution</h2>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    {Object.entries(gameCounts).map(([gameType, count]) => (
                      <Card key={gameType}>
                        <CardContent className="p-4 flex flex-col items-center">
                          <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center mb-2">
                            {getGameIcon(gameType)}
                          </div>
                          <p className="font-semibold">{gameType}</p>
                          <div className="text-sm text-muted-foreground">
                            {count} games ({((count / totalGames) * 100 || 0).toFixed(1)}%)
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="game-history">
              <Card>
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                      <CardTitle>Game History</CardTitle>
                      <CardDescription>View all games played on the platform</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setSortOrder(sortOrder === "desc" ? "asc" : "desc")}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {sortOrder === "desc" ? "Newest First" : "Oldest First"}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row gap-4 mt-4">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search games..."
                        className="pl-9"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <div className="flex space-x-2">
                      <Select value={gameFilter} onValueChange={setGameFilter}>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Filter by game" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Games</SelectItem>
                          <SelectItem value="coinToss">Coin Toss</SelectItem>
                          <SelectItem value="diceRoll">Dice Roll</SelectItem>
                          <SelectItem value="wheelFortune">Wheel of Fortune</SelectItem>
                          <SelectItem value="cardFlip">Card Flip</SelectItem>
                          <SelectItem value="luckyNumber">Lucky Number</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      <Select value={outcomeFilter} onValueChange={setOutcomeFilter}>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Filter by outcome" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Outcomes</SelectItem>
                          <SelectItem value="win">Wins</SelectItem>
                          <SelectItem value="loss">Losses</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {isLoadingHistory ? (
                    <div className="flex justify-center py-8">
                      <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : sortedGames && sortedGames.length > 0 ? (
                    <div className="rounded-md border">
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead>
                            <tr className="border-b border-border">
                              <th className="text-left py-3 px-4 font-medium">User</th>
                              <th className="text-left py-3 px-4 font-medium">Game</th>
                              <th className="text-left py-3 px-4 font-medium">Time</th>
                              <th className="text-left py-3 px-4 font-medium">Bet Amount</th>
                              <th className="text-left py-3 px-4 font-medium">Outcome</th>
                              <th className="text-left py-3 px-4 font-medium">Win Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                            {sortedGames.map((game) => (
                              <tr key={game.id} className="border-b border-border hover:bg-muted/30">
                                <td className="py-3 px-4">User #{game.userId}</td>
                                <td className="py-3 px-4">
                                  <div className="flex items-center">
                                    <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center mr-2">
                                      {getGameIcon(game.gameType)}
                                    </div>
                                    <span>{game.gameType}</span>
                                  </div>
                                </td>
                                <td className="py-3 px-4 text-muted-foreground">
                                  <div className="flex flex-col">
                                    <span>{format(new Date(game.createdAt), "MMM d, yyyy")}</span>
                                    <span className="text-xs">{format(new Date(game.createdAt), "h:mm a")}</span>
                                  </div>
                                </td>
                                <td className="py-3 px-4">₹{parseFloat(game.betAmount.toString()).toFixed(2)}</td>
                                <td className="py-3 px-4">
                                  <Badge className={game.outcome === "win" ? "bg-secondary text-secondary-foreground" : "bg-destructive text-destructive-foreground"}>
                                    {game.outcome.toUpperCase()}
                                  </Badge>
                                </td>
                                <td className="py-3 px-4">₹{parseFloat(game.winAmount.toString()).toFixed(2)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-10 text-muted-foreground">
                      <Coins className="h-12 w-12 mx-auto mb-4 opacity-30" />
                      <p>No game history found.</p>
                      {searchTerm || gameFilter !== "all" || outcomeFilter !== "all" ? (
                        <p className="text-sm mt-1">Try adjusting your filters.</p>
                      ) : null}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}