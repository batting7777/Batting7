import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
// Define our own ColumnDef type
type ColumnDef<TData, TValue = unknown> = {
  accessorKey?: string;
  header?: React.ReactNode;
  cell?: (props: { row: { original: TData } }) => React.ReactNode;
  id?: string; // Add support for id property
};
import Sidebar from "@/components/sidebar";
import TopNav from "@/components/top-nav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User, adminUpdateUserSchema } from "@shared/schema";
import { Search, Users, Edit, CircleDollarSign, Clock, BadgeCheck, BadgeX, RotateCw } from "lucide-react";
import { DataTable } from "@/components/ui/table";

type UserModifyFormValues = z.infer<typeof adminUpdateUserSchema>;

export default function UserManagement() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isUserDialogOpen, setIsUserDialogOpen] = useState(false);
  const { toast } = useToast();
  
  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };
  
  // Fetch all users
  const { data: users, isLoading: isLoadingUsers } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
  });
  
  // Filter users based on search term
  const filteredUsers = users?.filter(user => {
    if (!searchTerm) return true;
    
    const searchLower = searchTerm.toLowerCase();
    return (
      user.username.toLowerCase().includes(searchLower) ||
      user.id.toString().includes(searchLower) ||
      user.referralCode.toLowerCase().includes(searchLower)
    );
  });
  
  // Setup form for user modification
  const form = useForm<UserModifyFormValues>({
    resolver: zodResolver(adminUpdateUserSchema),
    defaultValues: {
      alwaysWin: false,
      alwaysLose: false,
      winLimit: null,
      balance: 0,
    },
  });
  
  // Reset form when selected user changes
  React.useEffect(() => {
    if (selectedUser) {
      form.reset({
        alwaysWin: selectedUser.alwaysWin || false,
        alwaysLose: selectedUser.alwaysLose || false,
        winLimit: selectedUser.winLimit ? parseFloat(selectedUser.winLimit.toString()) : null,
        balance: parseFloat(selectedUser.balance.toString()),
      });
    }
  }, [selectedUser, form]);
  
  const updateUserMutation = useMutation({
    mutationFn: async (values: UserModifyFormValues) => {
      if (!selectedUser) throw new Error("No user selected");
      
      const response = await apiRequest("PUT", `/api/admin/users/${selectedUser.id}`, values);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "User updated",
        description: `User ${selectedUser?.username} was updated successfully`,
      });
      
      // Refresh users data
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setIsUserDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleEditUser = (user: User) => {
    setSelectedUser(user);
    setIsUserDialogOpen(true);
  };
  
  const onSubmit = (values: UserModifyFormValues) => {
    updateUserMutation.mutate(values);
  };
  
  // Define table columns
  const columns: ColumnDef<User>[] = [
    {
      accessorKey: "id",
      header: "ID",
      cell: ({ row }) => <span className="font-mono text-xs">{row.original.id}</span>,
    },
    {
      accessorKey: "username",
      header: "Username",
      cell: ({ row }) => (
        <div className="flex items-center">
          <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center mr-2 text-xs">
            {row.original.username.substring(0, 2).toUpperCase()}
          </div>
          <span className="font-medium">{row.original.username}</span>
          {row.original.isAdmin && (
            <Badge variant="outline" className="ml-2 bg-primary/10 text-primary">Admin</Badge>
          )}
        </div>
      ),
    },
    {
      accessorKey: "balance",
      header: "Balance",
      cell: ({ row }) => (
        <div className="flex items-center">
          <CircleDollarSign className="h-4 w-4 mr-1 text-muted-foreground" />
          <span>₹{parseFloat(row.original.balance.toString()).toLocaleString('en-IN')}</span>
        </div>
      ),
    },
    {
      accessorKey: "referralCode",
      header: "Referral Code",
      cell: ({ row }) => (
        <Badge variant="outline" className="font-mono">
          {row.original.referralCode}
        </Badge>
      ),
    },
    {
      accessorKey: "createdAt",
      header: "Joined",
      cell: ({ row }) => (
        <div className="flex items-center">
          <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
          <span>{new Date(row.original.createdAt).toLocaleDateString()}</span>
        </div>
      ),
    },
    {
      accessorKey: "settings",
      header: "Game Settings",
      cell: ({ row }) => (
        <div className="flex items-center space-x-2">
          {row.original.alwaysWin && (
            <Badge className="bg-secondary text-secondary-foreground">Always Win</Badge>
          )}
          {row.original.alwaysLose && (
            <Badge className="bg-destructive text-destructive-foreground">Always Lose</Badge>
          )}
          {row.original.winLimit && (
            <Badge variant="outline">
              Win Limit: ₹{parseFloat(row.original.winLimit.toString()).toLocaleString('en-IN')}
            </Badge>
          )}
          {!row.original.alwaysWin && !row.original.alwaysLose && !row.original.winLimit && (
            <span className="text-muted-foreground text-sm">Default</span>
          )}
        </div>
      ),
    },
    {
      accessorKey: "actions",
      id: "actions",
      cell: ({ row }) => (
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => handleEditUser(row.original)}
        >
          <Edit className="h-4 w-4" />
        </Button>
      ),
    },
  ];
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar isMobileOpen={isMobileOpen} toggleSidebar={toggleSidebar} />
      
      <main className="flex-1 md:ml-64">
        <TopNav toggleSidebar={toggleSidebar} />
        
        <div className="p-4 md:p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">User Management</h1>
            <p className="text-muted-foreground">Manage users, balances, and game settings.</p>
          </div>
          
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <CardTitle>Users</CardTitle>
                  <CardDescription>Total users: {users?.length || 0}</CardDescription>
                </div>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search users..."
                    className="pl-9 w-full md:w-80"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoadingUsers ? (
                <div className="flex justify-center py-8">
                  <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : filteredUsers && filteredUsers.length > 0 ? (
                <CustomDataTable columns={columns} data={filteredUsers} searchKey="username" />
              ) : (
                <div className="text-center py-10 text-muted-foreground">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-30" />
                  <p>No users found.</p>
                  {searchTerm && (
                    <p className="text-sm mt-1">Try a different search term.</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* User Edit Dialog */}
          <Dialog open={isUserDialogOpen} onOpenChange={setIsUserDialogOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit User</DialogTitle>
                <DialogDescription>
                  {selectedUser && `Edit settings for ${selectedUser.username}`}
                </DialogDescription>
              </DialogHeader>
              
              {selectedUser && (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid gap-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <h4 className="text-sm font-medium">Game Outcome Control</h4>
                          <p className="text-xs text-muted-foreground">Control whether the user wins or loses games</p>
                        </div>
                        <div className="space-x-4 flex items-center">
                          <div className="flex items-center space-x-2">
                            <FormField
                              control={form.control}
                              name="alwaysWin"
                              render={({ field }) => (
                                <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value}
                                      onCheckedChange={(checked) => {
                                        field.onChange(checked);
                                        if (checked) {
                                          form.setValue("alwaysLose", false);
                                        }
                                      }}
                                    />
                                  </FormControl>
                                  <FormLabel className="font-normal text-sm flex items-center">
                                    <BadgeCheck className="h-4 w-4 mr-1 text-secondary" />
                                    Always Win
                                  </FormLabel>
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <FormField
                              control={form.control}
                              name="alwaysLose"
                              render={({ field }) => (
                                <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value}
                                      onCheckedChange={(checked) => {
                                        field.onChange(checked);
                                        if (checked) {
                                          form.setValue("alwaysWin", false);
                                        }
                                      }}
                                    />
                                  </FormControl>
                                  <FormLabel className="font-normal text-sm flex items-center">
                                    <BadgeX className="h-4 w-4 mr-1 text-destructive" />
                                    Always Lose
                                  </FormLabel>
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="winLimit"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Win Limit (₹)</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                placeholder="Enter maximum win amount"
                                {...field}
                                value={field.value === null ? "" : field.value}
                                onChange={(e) => field.onChange(e.target.value === "" ? null : parseFloat(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="balance"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Balance (₹)</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                placeholder="Enter user balance"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <DialogFooter>
                      <Button
                        type="submit"
                        disabled={updateUserMutation.isPending}
                      >
                        {updateUserMutation.isPending ? "Saving..." : "Save Changes"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              )}
            </DialogContent>
          </Dialog>
        </div>
      </main>
    </div>
  );
}

// Simple DataTable component with server-side sorting
function CustomDataTable<TData, TValue>({
  columns,
  data,
  searchKey,
}: {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
  searchKey?: string;
}) {
  return (
    <div className="rounded-md border">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border">
              {columns.map((column, index) => (
                <th
                  key={index}
                  className="text-left py-3 px-4 font-medium"
                >
                  {column.header as React.ReactNode}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, rowIndex) => (
              <tr key={rowIndex} className="border-b border-border hover:bg-muted/30">
                {columns.map((column, colIndex) => (
                  <td key={colIndex} className="py-3 px-4">
                    {column.cell ? (
                      // @ts-ignore - This is a simplified version without the full tanstack/table API
                      column.cell({ row: { original: row } })
                    ) : (
                      // @ts-ignore - Same as above
                      (row as any)[column.accessorKey as string]
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
