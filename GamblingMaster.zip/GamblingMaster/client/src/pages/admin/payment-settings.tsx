import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import TopNav from "@/components/top-nav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { SystemSettings } from "@shared/schema";
import { Plus, Trash2, Save, CreditCard, QrCode, Wallet, Download, Copy, RotateCw } from "lucide-react";

const paymentSettingsSchema = z.object({
  upiId: z.string().min(1, "UPI ID is required"),
  upiQrUrl: z.string().min(1, "UPI QR code URL is required"),
  usdtAddress: z.string().min(1, "USDT address is required"),
  usdtQrUrl: z.string().min(1, "USDT QR code URL is required"),
  minUpiDeposit: z.coerce.number().min(1, "Minimum UPI deposit must be at least 1"),
  maxUpiDeposit: z.coerce.number().min(1, "Maximum UPI deposit must be at least 1"),
  minUsdtDeposit: z.coerce.number().min(1, "Minimum USDT deposit must be at least 1"),
  maxUsdtRejections: z.coerce.number().min(1, "Maximum USDT rejections must be at least 1"),
  additionalUpiIds: z.array(z.string()).optional(),
  additionalUpiQrUrls: z.array(z.string()).optional(),
  additionalCryptoAddresses: z.array(z.string()).optional(),
  additionalCryptoQrUrls: z.array(z.string()).optional(),
});

type PaymentSettingsFormValues = z.infer<typeof paymentSettingsSchema>;

export default function PaymentSettings() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { toast } = useToast();
  
  // State for additional payment methods
  const [additionalUpiIds, setAdditionalUpiIds] = useState<string[]>([]);
  const [additionalUpiQrUrls, setAdditionalUpiQrUrls] = useState<string[]>([]);
  const [additionalCryptoAddresses, setAdditionalCryptoAddresses] = useState<string[]>([]);
  const [additionalCryptoQrUrls, setAdditionalCryptoQrUrls] = useState<string[]>([]);
  
  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };
  
  // Setup form for settings with default values
  const formMethods = useForm<PaymentSettingsFormValues>({
    resolver: zodResolver(paymentSettingsSchema),
    defaultValues: {
      upiId: "",
      upiQrUrl: "",
      usdtAddress: "",
      usdtQrUrl: "",
      minUpiDeposit: 500,
      maxUpiDeposit: 30000,
      minUsdtDeposit: 10,
      maxUsdtRejections: 3,
      additionalUpiIds: [],
      additionalUpiQrUrls: [],
      additionalCryptoAddresses: [],
      additionalCryptoQrUrls: [],
    },
  });
  
  // Fetch system settings
  const { data: settings, isLoading: isLoadingSettings } = useQuery<SystemSettings>({
    queryKey: ["/api/settings"]
  });
  
  // Effect to handle settings data when it loads
  useEffect(() => {
    if (settings) {
      // Initialize form with current settings
      formMethods.reset({
        upiId: settings.upiId || "",
        upiQrUrl: settings.upiQrUrl || "",
        usdtAddress: settings.usdtAddress || "",
        usdtQrUrl: settings.usdtQrUrl || "",
        minUpiDeposit: parseFloat(settings.minUpiDeposit?.toString() || "500"),
        maxUpiDeposit: parseFloat(settings.maxUpiDeposit?.toString() || "30000"),
        minUsdtDeposit: parseFloat(settings.minUsdtDeposit?.toString() || "10"),
        maxUsdtRejections: settings.maxUsdtRejections || 3,
        additionalUpiIds: [],
        additionalUpiQrUrls: [],
        additionalCryptoAddresses: [],
        additionalCryptoQrUrls: [],
      });
      
      // Set additional payment methods from JSON arrays in settings
      try {
        if (settings.additionalUpiIds) {
          const upiIds = typeof settings.additionalUpiIds === 'string' 
            ? JSON.parse(settings.additionalUpiIds) 
            : settings.additionalUpiIds;
          setAdditionalUpiIds(Array.isArray(upiIds) ? upiIds : []);
        }
        
        if (settings.additionalUpiQrUrls) {
          const upiQrUrls = typeof settings.additionalUpiQrUrls === 'string' 
            ? JSON.parse(settings.additionalUpiQrUrls) 
            : settings.additionalUpiQrUrls;
          setAdditionalUpiQrUrls(Array.isArray(upiQrUrls) ? upiQrUrls : []);
        }
        
        if (settings.additionalCryptoAddresses) {
          const cryptoAddresses = typeof settings.additionalCryptoAddresses === 'string' 
            ? JSON.parse(settings.additionalCryptoAddresses) 
            : settings.additionalCryptoAddresses;
          setAdditionalCryptoAddresses(Array.isArray(cryptoAddresses) ? cryptoAddresses : []);
        }
        
        if (settings.additionalCryptoQrUrls) {
          const cryptoQrUrls = typeof settings.additionalCryptoQrUrls === 'string' 
            ? JSON.parse(settings.additionalCryptoQrUrls) 
            : settings.additionalCryptoQrUrls;
          setAdditionalCryptoQrUrls(Array.isArray(cryptoQrUrls) ? cryptoQrUrls : []);
        }
      } catch (error) {
        console.error("Error parsing JSON arrays:", error);
      }
    }
  }, [settings]);
  
  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: PaymentSettingsFormValues) => {
      const fullData = {
        ...data,
        // Include existing settings that we don't want to change
        minWithdrawalAmount: parseFloat(settings?.minWithdrawalAmount?.toString() || "100"),
        maxWithdrawalAmount: parseFloat(settings?.maxWithdrawalAmount?.toString() || "10000"),
        referralBonus: parseFloat(settings?.referralBonus?.toString() || "100"),
        // Add the additional payment methods
        additionalUpiIds: additionalUpiIds,
        additionalUpiQrUrls: additionalUpiQrUrls,
        additionalCryptoAddresses: additionalCryptoAddresses,
        additionalCryptoQrUrls: additionalCryptoQrUrls,
      };
      
      const res = await apiRequest("PUT", "/api/admin/settings", fullData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Settings updated",
        description: "Payment settings have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update settings",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (values: PaymentSettingsFormValues) => {
    updateSettingsMutation.mutate(values);
  };
  
  // Handle adding new payment options
  const addUpiOption = () => {
    setAdditionalUpiIds([...additionalUpiIds, ""]);
    setAdditionalUpiQrUrls([...additionalUpiQrUrls, ""]);
  };
  
  const addCryptoOption = () => {
    setAdditionalCryptoAddresses([...additionalCryptoAddresses, ""]);
    setAdditionalCryptoQrUrls([...additionalCryptoQrUrls, ""]);
  };
  
  // Handle removing payment options
  const removeUpiOption = (index: number) => {
    setAdditionalUpiIds(additionalUpiIds.filter((_, i) => i !== index));
    setAdditionalUpiQrUrls(additionalUpiQrUrls.filter((_, i) => i !== index));
  };
  
  const removeCryptoOption = (index: number) => {
    setAdditionalCryptoAddresses(additionalCryptoAddresses.filter((_, i) => i !== index));
    setAdditionalCryptoQrUrls(additionalCryptoQrUrls.filter((_, i) => i !== index));
  };
  
  // Handle updating the additional payment options
  const updateUpiId = (index: number, value: string) => {
    const newUpiIds = [...additionalUpiIds];
    newUpiIds[index] = value;
    setAdditionalUpiIds(newUpiIds);
  };
  
  const updateUpiQrUrl = (index: number, value: string) => {
    const newUpiQrUrls = [...additionalUpiQrUrls];
    newUpiQrUrls[index] = value;
    setAdditionalUpiQrUrls(newUpiQrUrls);
  };
  
  const updateCryptoAddress = (index: number, value: string) => {
    const newCryptoAddresses = [...additionalCryptoAddresses];
    newCryptoAddresses[index] = value;
    setAdditionalCryptoAddresses(newCryptoAddresses);
  };
  
  const updateCryptoQrUrl = (index: number, value: string) => {
    const newCryptoQrUrls = [...additionalCryptoQrUrls];
    newCryptoQrUrls[index] = value;
    setAdditionalCryptoQrUrls(newCryptoQrUrls);
  };
  
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar isMobileOpen={isMobileOpen} toggleSidebar={toggleSidebar} />
      
      <div className="flex-1">
        <TopNav toggleSidebar={toggleSidebar} />
        
        <main className="p-4 md:p-6 max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-3xl font-bold tracking-tight">Payment Settings</h1>
          </div>
          
          {isLoadingSettings ? (
            <div className="flex items-center justify-center h-64">
              <RotateCw className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <Tabs defaultValue="upi" className="w-full">
              <TabsList className="mb-4">
                <TabsTrigger value="upi">UPI Settings</TabsTrigger>
                <TabsTrigger value="usdt">USDT Settings</TabsTrigger>
                <TabsTrigger value="limits">Deposit Limits</TabsTrigger>
              </TabsList>
              
              <Form {...formMethods}>
                <form onSubmit={formMethods.handleSubmit(onSubmit)} className="space-y-8">
                  <TabsContent value="upi" className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Primary UPI Details</CardTitle>
                        <CardDescription>Configure the main UPI ID and QR code for payments.</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <FormField
                          control={formMethods.control}
                          name="upiId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>UPI ID</FormLabel>
                              <FormControl>
                                <Input placeholder="example@ybl" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={formMethods.control}
                          name="upiQrUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>UPI QR Code URL</FormLabel>
                              <FormControl>
                                <Input placeholder="https://example.com/qr.png" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        {settings?.upiQrUrl && (
                          <div className="mt-4">
                            <p className="text-sm font-medium mb-2">Current QR Code Preview:</p>
                            <div className="w-48 h-48 mx-auto border rounded bg-white">
                              <img 
                                src={settings.upiQrUrl} 
                                alt="UPI QR Code" 
                                className="w-full h-full object-contain"
                                onError={(e) => (e.currentTarget.src = "https://placehold.co/200x200/png?text=Invalid+QR")}
                              />
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Additional UPI Options</CardTitle>
                        <CardDescription>Add multiple UPI IDs and QR codes for payments.</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {additionalUpiIds.map((upiId, index) => (
                          <div key={index} className="border p-4 rounded-md space-y-4">
                            <div className="flex justify-between items-center">
                              <h4 className="font-medium">UPI Option #{index + 1}</h4>
                              <Button 
                                type="button" 
                                variant="ghost" 
                                size="sm"
                                onClick={() => removeUpiOption(index)}
                              >
                                <Trash2 className="h-4 w-4 mr-1" />
                                Remove
                              </Button>
                            </div>
                            
                            <div className="grid gap-4">
                              <div>
                                <FormLabel>UPI ID</FormLabel>
                                <Input
                                  value={upiId}
                                  onChange={(e) => updateUpiId(index, e.target.value)}
                                  placeholder="alternate@upi"
                                />
                              </div>
                              
                              <div>
                                <FormLabel>QR Code URL</FormLabel>
                                <Input
                                  value={additionalUpiQrUrls[index] || ""}
                                  onChange={(e) => updateUpiQrUrl(index, e.target.value)}
                                  placeholder="https://example.com/qr2.png"
                                />
                              </div>
                              
                              {additionalUpiQrUrls[index] && (
                                <div>
                                  <p className="text-sm font-medium mb-2">QR Code Preview:</p>
                                  <div className="w-32 h-32 border rounded bg-white">
                                    <img 
                                      src={additionalUpiQrUrls[index]} 
                                      alt={`UPI QR Code ${index + 1}`} 
                                      className="w-full h-full object-contain"
                                      onError={(e) => (e.currentTarget.src = "https://placehold.co/200x200/png?text=Invalid+QR")}
                                    />
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                        
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={addUpiOption}
                          className="w-full mt-4"
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add UPI Option
                        </Button>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="usdt" className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Primary USDT Details</CardTitle>
                        <CardDescription>Configure the main USDT wallet address and QR code for payments.</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <FormField
                          control={formMethods.control}
                          name="usdtAddress"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>USDT Wallet Address</FormLabel>
                              <FormControl>
                                <Input placeholder="0x1234567890abcdef" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={formMethods.control}
                          name="usdtQrUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>USDT QR Code URL</FormLabel>
                              <FormControl>
                                <Input placeholder="https://example.com/usdt_qr.png" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        {settings?.usdtQrUrl && (
                          <div className="mt-4">
                            <p className="text-sm font-medium mb-2">Current QR Code Preview:</p>
                            <div className="w-48 h-48 mx-auto border rounded bg-white">
                              <img 
                                src={settings.usdtQrUrl} 
                                alt="USDT QR Code" 
                                className="w-full h-full object-contain"
                                onError={(e) => (e.currentTarget.src = "https://placehold.co/200x200/png?text=Invalid+QR")}
                              />
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Additional Crypto Options</CardTitle>
                        <CardDescription>Add multiple cryptocurrency addresses and QR codes for payments.</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {additionalCryptoAddresses.map((address, index) => (
                          <div key={index} className="border p-4 rounded-md space-y-4">
                            <div className="flex justify-between items-center">
                              <h4 className="font-medium">Crypto Option #{index + 1}</h4>
                              <Button 
                                type="button" 
                                variant="ghost" 
                                size="sm"
                                onClick={() => removeCryptoOption(index)}
                              >
                                <Trash2 className="h-4 w-4 mr-1" />
                                Remove
                              </Button>
                            </div>
                            
                            <div className="grid gap-4">
                              <div>
                                <FormLabel>Wallet Address</FormLabel>
                                <Input
                                  value={address}
                                  onChange={(e) => updateCryptoAddress(index, e.target.value)}
                                  placeholder="0xalternate..."
                                />
                              </div>
                              
                              <div>
                                <FormLabel>QR Code URL</FormLabel>
                                <Input
                                  value={additionalCryptoQrUrls[index] || ""}
                                  onChange={(e) => updateCryptoQrUrl(index, e.target.value)}
                                  placeholder="https://example.com/crypto_qr2.png"
                                />
                              </div>
                              
                              {additionalCryptoQrUrls[index] && (
                                <div>
                                  <p className="text-sm font-medium mb-2">QR Code Preview:</p>
                                  <div className="w-32 h-32 border rounded bg-white">
                                    <img 
                                      src={additionalCryptoQrUrls[index]} 
                                      alt={`Crypto QR Code ${index + 1}`} 
                                      className="w-full h-full object-contain"
                                      onError={(e) => (e.currentTarget.src = "https://placehold.co/200x200/png?text=Invalid+QR")}
                                    />
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                        
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={addCryptoOption}
                          className="w-full mt-4"
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Crypto Option
                        </Button>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="limits" className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Deposit Limits</CardTitle>
                        <CardDescription>Configure minimum and maximum deposit amounts for each payment method.</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={formMethods.control}
                            name="minUpiDeposit"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Minimum UPI Deposit (INR)</FormLabel>
                                <FormControl>
                                  <Input type="number" min={1} {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={formMethods.control}
                            name="maxUpiDeposit"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Maximum UPI Deposit (INR)</FormLabel>
                                <FormControl>
                                  <Input type="number" min={1} {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={formMethods.control}
                            name="minUsdtDeposit"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Minimum USDT Deposit</FormLabel>
                                <FormControl>
                                  <Input type="number" min={1} {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={formMethods.control}
                            name="maxUsdtRejections"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Max USDT Rejections Before Block</FormLabel>
                                <FormControl>
                                  <Input type="number" min={1} {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  <div className="flex justify-end">
                    <Button 
                      type="submit" 
                      disabled={updateSettingsMutation.isPending}
                      className="w-full sm:w-auto"
                    >
                      {updateSettingsMutation.isPending && (
                        <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      Save Settings
                    </Button>
                  </div>
                </form>
              </Form>
            </Tabs>
          )}
        </main>
      </div>
    </div>
  );
}