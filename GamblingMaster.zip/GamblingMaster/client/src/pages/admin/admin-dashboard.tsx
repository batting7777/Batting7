import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import TopNav from "@/components/top-nav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { format, subDays } from "date-fns";
import { User, GameHistory, Transaction, WithdrawalRequest } from "@shared/schema";
import { Users, CreditCard, Coins, TrendingUp, Activity, ArrowUpRight, FileBarChart, Wallet, UsersRound } from "lucide-react";

export default function AdminDashboard() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };

  // Fetch all users
  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
  });

  // Fetch all game history
  const { data: gameHistory } = useQuery<GameHistory[]>({
    queryKey: ["/api/admin/games/history"],
  });

  // Fetch all transactions
  const { data: transactions } = useQuery<Transaction[]>({
    queryKey: ["/api/admin/transactions"],
  });

  // Fetch all withdrawals
  const { data: withdrawals } = useQuery<WithdrawalRequest[]>({
    queryKey: ["/api/admin/withdrawals"],
  });

  // Calculate total users
  const totalUsers = users?.length || 0;

  // Calculate total active users (played a game in the last 7 days)
  const activeUsers = gameHistory?.filter(game => {
    const gameDate = new Date(game.createdAt);
    const sevenDaysAgo = subDays(new Date(), 7);
    return gameDate >= sevenDaysAgo;
  }).reduce((acc, game) => {
    if (!acc.includes(game.userId)) {
      acc.push(game.userId);
    }
    return acc;
  }, [] as number[]).length || 0;

  // Calculate total revenue
  const totalRevenue = gameHistory?.reduce((acc, game) => {
    if (game.outcome === "loss") {
      return acc + parseFloat(game.betAmount.toString());
    }
    return acc - parseFloat(game.winAmount.toString()) + parseFloat(game.betAmount.toString());
  }, 0) || 0;

  // Calculate total user balances
  const totalUserBalance = users?.reduce((acc, user) => {
    return acc + parseFloat(user.balance.toString());
  }, 0) || 0;

  // Calculate pending withdrawals
  const pendingWithdrawals = withdrawals?.filter(w => w.status === "pending").length || 0;
  const pendingWithdrawalAmount = withdrawals?.filter(w => w.status === "pending")
    .reduce((acc, w) => acc + parseFloat(w.amount.toString()), 0) || 0;

  // Prepare game revenue by type data
  const gameRevenueByType = gameHistory?.reduce((acc, game) => {
    const gameType = game.gameType;
    const existingGame = acc.find(g => g.name === gameType);
    
    const revenue = game.outcome === "loss" 
      ? parseFloat(game.betAmount.toString()) 
      : parseFloat(game.betAmount.toString()) - parseFloat(game.winAmount.toString());
    
    if (existingGame) {
      existingGame.revenue += revenue;
      existingGame.count += 1;
    } else {
      acc.push({ name: gameType, revenue, count: 1 });
    }
    
    return acc;
  }, [] as { name: string, revenue: number, count: number }[]) || [];

  // Prepare daily revenue data
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), i);
    return {
      date: format(date, "MMM dd"),
      fullDate: date,
      revenue: 0,
      games: 0
    };
  }).reverse();

  const dailyRevenue = gameHistory?.reduce((acc, game) => {
    const gameDate = new Date(game.createdAt);
    const dayIndex = acc.findIndex(day => {
      const dayDate = day.fullDate;
      return gameDate.getDate() === dayDate.getDate() && gameDate.getMonth() === dayDate.getMonth();
    });

    if (dayIndex !== -1) {
      const revenue = game.outcome === "loss" 
        ? parseFloat(game.betAmount.toString()) 
        : parseFloat(game.betAmount.toString()) - parseFloat(game.winAmount.toString());
      
      acc[dayIndex].revenue += revenue;
      acc[dayIndex].games += 1;
    }

    return acc;
  }, last7Days) || last7Days;

  // Game outcome distribution
  const outcomeDistribution = gameHistory?.reduce((acc, game) => {
    const outcome = game.outcome;
    const existingOutcome = acc.find(o => o.name === outcome);
    
    if (existingOutcome) {
      existingOutcome.value += 1;
    } else {
      acc.push({ name: outcome, value: 1 });
    }
    
    return acc;
  }, [] as { name: string, value: number }[]) || [];

  // Colors for pie chart
  const COLORS = ['#00C853', '#F44336'];

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar isMobileOpen={isMobileOpen} toggleSidebar={toggleSidebar} />
      
      <main className="flex-1 md:ml-64">
        <TopNav toggleSidebar={toggleSidebar} />
        
        <div className="p-4 md:p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
            <p className="text-muted-foreground">Overview of platform statistics and performance.</p>
          </div>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Users</p>
                    <h3 className="text-2xl font-bold mt-1">{totalUsers}</h3>
                  </div>
                  <div className="h-12 w-12 rounded-lg bg-primary/20 flex items-center justify-center">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="text-sm text-muted-foreground mt-4 flex items-center">
                  <UsersRound className="h-4 w-4 mr-1" /> {activeUsers} active in last 7 days
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                    <h3 className="text-2xl font-bold mt-1">₹{totalRevenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</h3>
                  </div>
                  <div className="h-12 w-12 rounded-lg bg-secondary/20 flex items-center justify-center">
                    <CreditCard className="h-6 w-6 text-secondary" />
                  </div>
                </div>
                <div className="text-sm text-secondary mt-4 flex items-center">
                  <TrendingUp className="h-4 w-4 mr-1" /> Positive balance
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">User Balances</p>
                    <h3 className="text-2xl font-bold mt-1">₹{totalUserBalance.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</h3>
                  </div>
                  <div className="h-12 w-12 rounded-lg bg-accent/20 flex items-center justify-center">
                    <Coins className="h-6 w-6 text-accent" />
                  </div>
                </div>
                <div className="text-sm text-muted-foreground mt-4 flex items-center">
                  <Wallet className="h-4 w-4 mr-1" /> Total funds in user wallets
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Pending Withdrawals</p>
                    <h3 className="text-2xl font-bold mt-1">{pendingWithdrawals}</h3>
                  </div>
                  <div className="h-12 w-12 rounded-lg bg-destructive/20 flex items-center justify-center">
                    <Activity className="h-6 w-6 text-destructive" />
                  </div>
                </div>
                <div className="text-sm text-muted-foreground mt-4 flex items-center">
                  <ArrowUpRight className="h-4 w-4 mr-1" /> ₹{pendingWithdrawalAmount.toLocaleString('en-IN', { maximumFractionDigits: 0 })} pending
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Revenue (Last 7 Days)</CardTitle>
                <CardDescription>Daily platform revenue and game activity</CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={dailyRevenue}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2A" />
                    <XAxis dataKey="date" stroke="#999999" />
                    <YAxis stroke="#999999" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1E1E1E', borderColor: '#2A2A2A', borderRadius: '0.5rem' }}
                    />
                    <Legend />
                    <Line type="monotone" dataKey="revenue" name="Revenue (₹)" stroke="#6200EA" strokeWidth={2} />
                    <Line type="monotone" dataKey="games" name="Games Played" stroke="#00C853" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Game Performance</CardTitle>
                <CardDescription>Revenue breakdown by game type</CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={gameRevenueByType}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2A" />
                    <XAxis dataKey="name" stroke="#999999" />
                    <YAxis stroke="#999999" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1E1E1E', borderColor: '#2A2A2A', borderRadius: '0.5rem' }}
                    />
                    <Legend />
                    <Bar dataKey="revenue" name="Revenue (₹)" fill="#6200EA" />
                    <Bar dataKey="count" name="Games Played" fill="#FF9100" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
          
          {/* More Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle>Game Outcomes</CardTitle>
                <CardDescription>Win vs Loss distribution</CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={outcomeDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {outcomeDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1E1E1E', borderColor: '#2A2A2A', borderRadius: '0.5rem' }}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Latest games and transactions</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="games">
                  <div className="flex justify-end mb-4">
                    <TabsList>
                      <TabsTrigger value="games">Games</TabsTrigger>
                      <TabsTrigger value="transactions">Transactions</TabsTrigger>
                    </TabsList>
                  </div>
                
                  <TabsContent value="games" className="mt-0">
                    <div className="space-y-4">
                      {gameHistory?.slice(0, 5).map((game) => (
                        <div key={game.id} className="flex items-center border-b border-border pb-4 last:border-0 last:pb-0">
                          <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center mr-3">
                            <FileBarChart className="h-5 w-5 text-muted-foreground" />
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between">
                              <div>
                                <p className="font-medium">{game.gameType}</p>
                                <p className="text-sm text-muted-foreground">
                                  User #{game.userId} • {format(new Date(game.createdAt), "MMM d, h:mm a")}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="font-medium">₹{parseFloat(game.betAmount.toString()).toFixed(2)}</p>
                                <p className={`text-sm ${game.outcome === 'win' ? 'text-secondary' : 'text-destructive'}`}>
                                  {game.outcome === 'win' ? '+' : '-'}₹{game.outcome === 'win' ? parseFloat(game.winAmount.toString()).toFixed(2) : parseFloat(game.betAmount.toString()).toFixed(2)}
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="transactions" className="mt-0">
                    <div className="space-y-4">
                      {transactions?.slice(0, 5).map((transaction) => (
                        <div key={transaction.id} className="flex items-center border-b border-border pb-4 last:border-0 last:pb-0">
                          <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center mr-3">
                            <Wallet className="h-5 w-5 text-muted-foreground" />
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between">
                              <div>
                                <p className="font-medium capitalize">{transaction.type}</p>
                                <p className="text-sm text-muted-foreground">
                                  User #{transaction.userId} • {format(new Date(transaction.createdAt), "MMM d, h:mm a")}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="font-medium">₹{parseFloat(transaction.amount.toString()).toFixed(2)}</p>
                                <p className={`text-sm ${
                                  transaction.status === 'completed' ? 'text-secondary' : 
                                  transaction.status === 'failed' ? 'text-destructive' : 
                                  'text-yellow-500'
                                }`}>
                                  {transaction.status}
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
