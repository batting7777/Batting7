import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import TopNav from "@/components/top-nav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Transaction } from "@shared/schema";
import { RotateCw, Copy, Share2, Share, Facebook, Twitter, Mail, Clipboard, Award, Users, CheckCircle } from "lucide-react";

export default function ReferralPage() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  
  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };
  
  // Fetch system settings for referral bonus amount
  const { data: settings } = useQuery({
    queryKey: ["/api/settings"],
  });
  
  // Fetch referral transactions
  const { data: transactions, isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/wallet/transactions"],
    select: (data) => data.filter(tx => tx.type === "referral")
  });
  
  const copyReferralCode = () => {
    if (user?.referralCode) {
      navigator.clipboard.writeText(user.referralCode);
      setCopied(true);
      toast({
        title: "Referral code copied",
        description: "Share this code with your friends to earn bonuses!"
      });
      
      // Reset copied state after 3 seconds
      setTimeout(() => setCopied(false), 3000);
    }
  };
  
  const shareViaWhatsApp = () => {
    if (user?.referralCode) {
      const text = `Join LuckyPlay Casino and get ₹1,000 bonus! Use my referral code: ${user.referralCode}`;
      const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
      window.open(url, '_blank');
    }
  };
  
  const shareViaFacebook = () => {
    if (user?.referralCode) {
      const text = `Join LuckyPlay Casino and get ₹1,000 bonus! Use my referral code: ${user.referralCode}`;
      const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}&quote=${encodeURIComponent(text)}`;
      window.open(url, '_blank');
    }
  };
  
  const shareViaTwitter = () => {
    if (user?.referralCode) {
      const text = `Join LuckyPlay Casino and get ₹1,000 bonus! Use my referral code: ${user.referralCode}`;
      const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`;
      window.open(url, '_blank');
    }
  };
  
  const shareViaEmail = () => {
    if (user?.referralCode) {
      const subject = "Join LuckyPlay Casino";
      const body = `Join LuckyPlay Casino and get ₹1,000 bonus! Use my referral code: ${user.referralCode}`;
      const url = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      window.location.href = url;
    }
  };
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar isMobileOpen={isMobileOpen} toggleSidebar={toggleSidebar} />
      
      <main className="flex-1 md:ml-64">
        <TopNav toggleSidebar={toggleSidebar} />
        
        <div className="p-4 md:p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Refer & Earn</h1>
            <p className="text-muted-foreground">Invite friends and earn bonus cash for every successful referral.</p>
          </div>
          
          {/* Main Referral Card */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <Card className="lg:col-span-2 bg-gradient-to-r from-primary to-purple-600">
              <CardContent className="p-8">
                <div className="flex flex-col items-center md:items-start text-white">
                  <div className="inline-flex items-center mb-4">
                    <Award className="h-8 w-8 mr-2" />
                    <h2 className="text-2xl font-bold">Refer Friends & Earn Rewards</h2>
                  </div>
                  
                  <p className="text-white/80 mb-6 text-center md:text-left">
                    Share your unique referral code with friends. When they sign up using your code, 
                    you'll receive ₹{settings?.referralBonus || 100} bonus cash!
                  </p>
                  
                  <div className="w-full bg-white/10 p-1 rounded-lg mb-6">
                    <div className="flex items-center">
                      <Input
                        value={user?.referralCode || ""}
                        readOnly
                        className="bg-transparent border-0 text-white placeholder:text-white/50 focus-visible:ring-0 focus-visible:ring-offset-0"
                      />
                      <Button 
                        variant="secondary" 
                        className="text-primary"
                        onClick={copyReferralCode}
                      >
                        {copied ? (
                          <><CheckCircle className="h-4 w-4 mr-1" /> Copied</>
                        ) : (
                          <><Copy className="h-4 w-4 mr-1" /> Copy</>
                        )}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="w-full">
                    <p className="text-white/80 mb-4 text-center md:text-left">Share via:</p>
                    <div className="flex flex-wrap justify-center md:justify-start gap-3">
                      <Button 
                        variant="outline" 
                        className="bg-white/10 border-white/20 hover:bg-white/20 text-white"
                        onClick={shareViaWhatsApp}
                      >
                        <Share className="h-4 w-4 mr-2" />
                        WhatsApp
                      </Button>
                      <Button 
                        variant="outline" 
                        className="bg-white/10 border-white/20 hover:bg-white/20 text-white"
                        onClick={shareViaFacebook}
                      >
                        <Facebook className="h-4 w-4 mr-2" />
                        Facebook
                      </Button>
                      <Button 
                        variant="outline" 
                        className="bg-white/10 border-white/20 hover:bg-white/20 text-white"
                        onClick={shareViaTwitter}
                      >
                        <Twitter className="h-4 w-4 mr-2" />
                        Twitter
                      </Button>
                      <Button 
                        variant="outline" 
                        className="bg-white/10 border-white/20 hover:bg-white/20 text-white"
                        onClick={shareViaEmail}
                      >
                        <Mail className="h-4 w-4 mr-2" />
                        Email
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Stats Card */}
            <Card>
              <CardHeader>
                <CardTitle>Your Referral Stats</CardTitle>
                <CardDescription>Track your referral earnings and bonuses.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Total Referral Earnings</p>
                    <p className="text-3xl font-bold text-secondary">
                      ₹{parseFloat(user?.referralBalance?.toString() || "0").toLocaleString('en-IN')}
                    </p>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Referral Bonus per Friend</p>
                    <p className="text-xl font-bold">₹{settings?.referralBonus || 100}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Your Referral Code</p>
                    <div className="flex items-center">
                      <Badge variant="outline" className="text-lg font-mono py-1 px-3 mr-2">{user?.referralCode}</Badge>
                      <Button variant="ghost" size="icon" onClick={copyReferralCode}>
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* How It Works */}
          <section className="mb-8">
            <Card>
              <CardHeader>
                <CardTitle>How It Works</CardTitle>
                <CardDescription>Follow these simple steps to refer friends and earn bonuses.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="flex flex-col items-center text-center p-4">
                    <div className="h-12 w-12 rounded-full bg-primary/20 text-primary flex items-center justify-center mb-4">
                      <Clipboard className="h-6 w-6" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">Step 1: Copy Your Code</h3>
                    <p className="text-muted-foreground">Copy your unique referral code from this page.</p>
                  </div>
                  
                  <div className="flex flex-col items-center text-center p-4">
                    <div className="h-12 w-12 rounded-full bg-primary/20 text-primary flex items-center justify-center mb-4">
                      <Share2 className="h-6 w-6" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">Step 2: Share With Friends</h3>
                    <p className="text-muted-foreground">Share the code with friends via WhatsApp, social media, or email.</p>
                  </div>
                  
                  <div className="flex flex-col items-center text-center p-4">
                    <div className="h-12 w-12 rounded-full bg-primary/20 text-primary flex items-center justify-center mb-4">
                      <Award className="h-6 w-6" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">Step 3: Earn Rewards</h3>
                    <p className="text-muted-foreground">When friends sign up with your code, you both get bonus cash!</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>
          
          {/* Referral History */}
          <section>
            <Card>
              <CardHeader>
                <CardTitle>Referral History</CardTitle>
                <CardDescription>Recent bonuses earned from your referrals.</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingTransactions ? (
                  <div className="flex justify-center py-8">
                    <RotateCw className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : transactions && transactions.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 font-medium">Date</th>
                          <th className="text-left py-3 px-4 font-medium">Amount</th>
                          <th className="text-left py-3 px-4 font-medium">Status</th>
                          <th className="text-left py-3 px-4 font-medium">Notes</th>
                        </tr>
                      </thead>
                      <tbody>
                        {transactions.map((transaction) => (
                          <tr key={transaction.id} className="border-b border-border hover:bg-muted/30">
                            <td className="py-3 px-4 text-muted-foreground">{new Date(transaction.createdAt).toLocaleDateString()}</td>
                            <td className="py-3 px-4 text-secondary">+₹{parseFloat(transaction.amount.toString()).toFixed(2)}</td>
                            <td className="py-3 px-4">
                              <span className="px-2 py-1 rounded-md text-xs font-medium bg-secondary/20 text-secondary">
                                {transaction.status.toUpperCase()}
                              </span>
                            </td>
                            <td className="py-3 px-4">{transaction.notes || "-"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-10 text-muted-foreground">
                    <Users className="h-12 w-12 mx-auto mb-4 opacity-30" />
                    <p>No referral bonuses yet.</p>
                    <p className="text-sm mt-1">Share your code to start earning referral bonuses!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </section>
        </div>
      </main>
    </div>
  );
}
