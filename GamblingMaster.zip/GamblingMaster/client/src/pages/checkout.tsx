import { useState } from 'react';
import { useLocation, useRoute } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import Sidebar from '@/components/sidebar';
import TopNav from '@/components/top-nav';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Loader2, CreditCard, ArrowRight, Check, Copy, Wallet, QrCode } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';

// Form validation schema
const upiDepositSchema = z.object({
  amount: z.string()
    .refine(val => !isNaN(Number(val)), { message: "Amount must be a number" })
    .refine(val => Number(val) >= 500, { message: "Minimum deposit is ₹500" })
    .refine(val => Number(val) <= 30000, { message: "Maximum deposit is ₹30,000" }),
  utrNumber: z.string()
    .min(12, "UTR number must be at least 12 characters")
    .max(22, "UTR number must not exceed 22 characters")
});

const usdtDepositSchema = z.object({
  amount: z.string()
    .refine(val => !isNaN(Number(val)), { message: "Amount must be a number" })
    .refine(val => Number(val) > 0, { message: "Amount must be greater than 0" }),
  transactionId: z.string()
    .min(5, "Transaction ID must be at least 5 characters")
});

type UpiDepositFormValues = z.infer<typeof upiDepositSchema>;
type UsdtDepositFormValues = z.infer<typeof usdtDepositSchema>;

export default function Checkout() {
  const [match, params] = useRoute<{ paymentMethod?: string }>('/checkout/:paymentMethod?');
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);
  const [qrData, setQrData] = useState<{ qrUrl: string, upiId: string }>({ qrUrl: '', upiId: '' });
  const { toast } = useToast();
  
  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };

  // UPI Form
  const upiForm = useForm<UpiDepositFormValues>({
    resolver: zodResolver(upiDepositSchema),
    defaultValues: {
      amount: '',
      utrNumber: ''
    }
  });

  // USDT Form
  const usdtForm = useForm<UsdtDepositFormValues>({
    resolver: zodResolver(usdtDepositSchema),
    defaultValues: {
      amount: '',
      transactionId: ''
    }
  });

  // If no payment method is specified, default to 'upi'
  if (!match || !params.paymentMethod) {
    setLocation('/checkout/upi');
    return null;
  }

  const showQrCode = async (amount: string) => {
    try {
      setIsSubmitting(true);
      const res = await apiRequest('GET', '/api/payment-settings');
      const settings = await res.json();

      // Choose a random UPI option if multiple are available
      const upiOptions = settings.upiOptions || [];
      if (upiOptions.length === 0) {
        toast({
          title: "Configuration Error",
          description: "No UPI payment options are configured. Please contact support.",
          variant: "destructive"
        });
        return;
      }

      const randomUpi = upiOptions[Math.floor(Math.random() * upiOptions.length)];
      setQrData({
        qrUrl: randomUpi.qrUrl,
        upiId: randomUpi.upiId
      });
      setShowQrModal(true);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load payment details. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "UPI ID has been copied to your clipboard",
    });
  };

  const handleUpiSubmit = async (values: UpiDepositFormValues) => {
    try {
      setIsSubmitting(true);
      const res = await apiRequest('POST', '/api/deposit/upi', {
        amount: values.amount,
        utrNumber: values.utrNumber
      });
      
      if (res.ok) {
        toast({
          title: "Deposit Request Submitted",
          description: "Your UPI deposit request has been submitted for verification.",
        });
        // Reset form
        upiForm.reset();
        // Close QR modal
        setShowQrModal(false);
        // Invalidate user balance cache
        queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      } else {
        const error = await res.json();
        toast({
          title: "Deposit Failed",
          description: error.message || "Failed to process your deposit. Please try again.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUsdtSubmit = async (values: UsdtDepositFormValues) => {
    try {
      setIsSubmitting(true);
      const res = await apiRequest('POST', '/api/deposit/usdt', {
        amount: values.amount,
        transactionId: values.transactionId
      });
      
      if (res.ok) {
        toast({
          title: "Deposit Request Submitted",
          description: "Your USDT deposit request has been submitted for verification.",
        });
        // Reset form
        usdtForm.reset();
        // Invalidate user balance cache
        queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      } else {
        const error = await res.json();
        toast({
          title: "Deposit Failed",
          description: error.message || "Failed to process your deposit. Please try again.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar isMobileOpen={isMobileOpen} toggleSidebar={toggleSidebar} />
      
      <main className="flex-1 md:ml-64">
        <TopNav toggleSidebar={toggleSidebar} />
        
        <div className="p-4 md:p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Deposit Funds</h1>
            <p className="text-muted-foreground">Add money to your account using various payment methods.</p>
          </div>
          
          <Tabs defaultValue={params.paymentMethod} className="max-w-3xl mx-auto">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="upi" onClick={() => setLocation('/checkout/upi')}>UPI Payment</TabsTrigger>
              <TabsTrigger value="usdt" onClick={() => setLocation('/checkout/usdt')}>USDT Payment</TabsTrigger>
            </TabsList>
            
            <TabsContent value="upi">
              <Card>
                <CardHeader>
                  <CardTitle>UPI Deposit</CardTitle>
                  <CardDescription>₹500 - ₹30,000 | Instant Deposit</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...upiForm}>
                    <form className="space-y-4">
                      <FormField
                        control={upiForm.control}
                        name="amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Amount (₹)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="Enter amount" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="button" 
                        className="w-full"
                        disabled={!upiForm.getValues().amount || isNaN(Number(upiForm.getValues().amount)) || Number(upiForm.getValues().amount) < 500 || isSubmitting}
                        onClick={() => showQrCode(upiForm.getValues().amount)}
                      >
                        {isSubmitting ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <QrCode className="mr-2 h-4 w-4" />
                        )}
                        Show QR Code
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="usdt">
              <Card>
                <CardHeader>
                  <CardTitle>USDT Deposit</CardTitle>
                  <CardDescription>USDT TRC20 Network | Min. 5 USDT</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...usdtForm}>
                    <form onSubmit={usdtForm.handleSubmit(handleUsdtSubmit)} className="space-y-4">
                      <FormField
                        control={usdtForm.control}
                        name="amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Amount (USDT)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="Enter amount" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="p-4 bg-muted rounded-lg mb-4">
                        <p className="font-medium mb-2">Send USDT to:</p>
                        <div className="flex items-center justify-between mb-2">
                          <code className="bg-background p-2 rounded text-sm w-full overflow-hidden text-ellipsis">
                            TRVpGAcXQhTLvjVSJHAtfmxKZ1oPaK4nr3
                          </code>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => copyToClipboard("TRVpGAcXQhTLvjVSJHAtfmxKZ1oPaK4nr3")}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Important: Only send USDT through TRC20 network. Other networks are not supported and may result in loss of funds.
                        </p>
                      </div>
                      
                      <FormField
                        control={usdtForm.control}
                        name="transactionId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Transaction ID / Hash</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Enter USDT transaction ID" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <CreditCard className="mr-2 h-4 w-4" />
                        )}
                        Submit Deposit
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      {/* UPI QR Code Modal */}
      <Dialog open={showQrModal} onOpenChange={setShowQrModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Scan QR Code to Pay</DialogTitle>
            <DialogDescription>
              Scan this QR code with any UPI app to make payment of ₹{upiForm.getValues().amount}
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex flex-col items-center justify-center p-6">
            {qrData.qrUrl && (
              <div className="border-2 border-border p-2 rounded-lg mb-4">
                <img 
                  src={qrData.qrUrl} 
                  alt="UPI QR Code" 
                  className="w-64 h-64 object-contain"
                />
              </div>
            )}
            
            <div className="flex items-center mb-4">
              <p className="text-sm font-medium mr-2">UPI ID:</p>
              <code className="bg-muted text-sm p-1 rounded">{qrData.upiId}</code>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => copyToClipboard(qrData.upiId)}
              >
                <Copy className="h-3 w-3" />
              </Button>
            </div>
          </div>
          
          <div className="p-4 bg-muted rounded-lg mb-4">
            <p className="text-sm text-muted-foreground mb-2">After payment, please enter your UTR number below to confirm the transaction.</p>
            
            <Form {...upiForm}>
              <form onSubmit={upiForm.handleSubmit(handleUpiSubmit)}>
                <FormField
                  control={upiForm.control}
                  name="utrNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>UTR Number</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter UTR Number" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </form>
            </Form>
          </div>
          
          <DialogFooter className="flex items-center">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setShowQrModal(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={upiForm.handleSubmit(handleUpiSubmit)}
              disabled={!upiForm.getValues().utrNumber || isSubmitting}
            >
              {isSubmitting ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Check className="mr-2 h-4 w-4" />
              )}
              Confirm Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}