import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import GamePage from "@/pages/game-page";
import WalletPage from "@/pages/wallet-page";
import HistoryPage from "@/pages/history-page";
import ReferralPage from "@/pages/referral-page";
import Checkout from "@/pages/checkout";
import AdminDashboard from "@/pages/admin/admin-dashboard";
import UserManagement from "@/pages/admin/user-management";
import GameControls from "@/pages/admin/game-controls";
import WithdrawalManagement from "@/pages/admin/withdrawal-management";
import ReferralSettings from "@/pages/admin/referral-settings";
import PaymentSettings from "@/pages/admin/payment-settings";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "./hooks/use-auth";

function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path="/auth" component={AuthPage} />
      
      {/* Protected routes */}
      <Route path="/">
        <ProtectedRoute component={HomePage} />
      </Route>
      <Route path="/game/:gameType">
        <ProtectedRoute component={GamePage} />
      </Route>
      <Route path="/wallet">
        <ProtectedRoute component={WalletPage} />
      </Route>
      <Route path="/history">
        <ProtectedRoute component={HistoryPage} />
      </Route>
      <Route path="/referral">
        <ProtectedRoute component={ReferralPage} />
      </Route>
      <Route path="/checkout/:paymentMethod?">
        <ProtectedRoute component={Checkout} />
      </Route>
      
      {/* Admin routes */}
      <Route path="/admin">
        <ProtectedRoute component={AdminDashboard} admin={true} />
      </Route>
      <Route path="/admin/users">
        <ProtectedRoute component={UserManagement} admin={true} />
      </Route>
      <Route path="/admin/games">
        <ProtectedRoute component={GameControls} admin={true} />
      </Route>
      <Route path="/admin/withdrawals">
        <ProtectedRoute component={WithdrawalManagement} admin={true} />
      </Route>
      <Route path="/admin/referrals">
        <ProtectedRoute component={ReferralSettings} admin={true} />
      </Route>
      <Route path="/admin/payment-settings">
        <ProtectedRoute component={PaymentSettings} admin={true} />
      </Route>
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
